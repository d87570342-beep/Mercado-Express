import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import type { User, Product, Sale, CashMovement, BusinessType } from '../src/types/index.ts';

interface StoredUser extends User {
  passwordHash: string;
  salt: string;
}

interface DatabaseSchema {
  users: StoredUser[];
  products: Product[];
  sales: Sale[];
  cashMovements: CashMovement[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'mercadoexpress.json');

// Helper for password hashing using Node crypto
export function hashPassword(password: string, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return { hash, salt };
}

export function verifyPassword(password: string, hash: string, salt: string): boolean {
  const verify = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return verify === hash;
}

// Generate simple secure session tokens
const sessionStore = new Map<string, string>(); // token -> userId

export function createSessionToken(userId: string): string {
  const token = crypto.randomBytes(32).toString('hex');
  sessionStore.set(token, userId);
  return token;
}

export function getUserIdFromToken(token: string): string | null {
  return sessionStore.get(token) || null;
}

export function removeSessionToken(token: string): void {
  sessionStore.delete(token);
}

// Initialize seed data
function getInitialSeedData(): DatabaseSchema {
  const demoUserId = 'demo-user-bodega-1';
  const { hash: demoHash, salt: demoSalt } = hashPassword('demo123');

  const now = new Date();
  const todayStr = now.toISOString();

  // Create dates for today, yesterday, and earlier this week
  const dateToday1 = new Date(now.getTime() - 2 * 60 * 60 * 1000).toISOString();
  const dateToday2 = new Date(now.getTime() - 4 * 60 * 60 * 1000).toISOString();
  const dateYesterday = new Date(now.getTime() - 26 * 60 * 60 * 1000).toISOString();
  const dateTwoDaysAgo = new Date(now.getTime() - 50 * 60 * 60 * 1000).toISOString();

  const demoUser: StoredUser = {
    id: demoUserId,
    email: 'demo@mercadoexpress.com',
    name: 'Lucho Morales',
    businessName: 'Bodega Don Lucho',
    businessType: 'bodega',
    currency: 'S/.',
    phone: '987 654 321',
    createdAt: dateTwoDaysAgo,
    passwordHash: demoHash,
    salt: demoSalt
  };

  const demoProducts: Product[] = [
    {
      id: 'prod-1',
      userId: demoUserId,
      name: 'Arroz Extra Costeño 1kg',
      category: 'Abarrotes',
      quantity: 26,
      costPrice: 3.80,
      salePrice: 4.80,
      minStock: 10,
      unit: 'kg',
      createdAt: dateTwoDaysAgo,
      updatedAt: dateTwoDaysAgo
    },
    {
      id: 'prod-2',
      userId: demoUserId,
      name: 'Aceite Primor Premium 900ml',
      category: 'Abarrotes',
      quantity: 14,
      costPrice: 7.20,
      salePrice: 9.00,
      minStock: 6,
      unit: 'unid',
      createdAt: dateTwoDaysAgo,
      updatedAt: dateTwoDaysAgo
    },
    {
      id: 'prod-3',
      userId: demoUserId,
      name: 'Azúcar Rubia Dulfina 1kg',
      category: 'Abarrotes',
      quantity: 20,
      costPrice: 3.20,
      salePrice: 4.20,
      minStock: 8,
      unit: 'kg',
      createdAt: dateTwoDaysAgo,
      updatedAt: dateTwoDaysAgo
    },
    {
      id: 'prod-4',
      userId: demoUserId,
      name: 'Leche Gloria Azul 400g',
      category: 'Lácteos',
      quantity: 4, // Alerta stock bajo
      costPrice: 3.50,
      salePrice: 4.50,
      minStock: 12,
      unit: 'unid',
      createdAt: dateTwoDaysAgo,
      updatedAt: dateTwoDaysAgo
    },
    {
      id: 'prod-5',
      userId: demoUserId,
      name: 'Fideos Don Vittorio Spaghetti 500g',
      category: 'Abarrotes',
      quantity: 28,
      costPrice: 2.20,
      salePrice: 3.20,
      minStock: 10,
      unit: 'paq',
      createdAt: dateTwoDaysAgo,
      updatedAt: dateTwoDaysAgo
    },
    {
      id: 'prod-6',
      userId: demoUserId,
      name: 'Huevos de Gallina (kg)',
      category: 'Abarrotes',
      quantity: 3, // Alerta stock bajo
      costPrice: 6.50,
      salePrice: 8.50,
      minStock: 8,
      unit: 'kg',
      createdAt: dateTwoDaysAgo,
      updatedAt: dateTwoDaysAgo
    },
    {
      id: 'prod-7',
      userId: demoUserId,
      name: 'Pan Francés fresco (docena)',
      category: 'Panadería',
      quantity: 12,
      costPrice: 2.00,
      salePrice: 3.00,
      minStock: 5,
      unit: 'paq',
      createdAt: dateTwoDaysAgo,
      updatedAt: dateTwoDaysAgo
    },
    {
      id: 'prod-8',
      userId: demoUserId,
      name: 'Gaseosa Inca Kola 1.5L',
      category: 'Bebidas',
      quantity: 15,
      costPrice: 5.50,
      salePrice: 7.50,
      minStock: 6,
      unit: 'unid',
      createdAt: dateTwoDaysAgo,
      updatedAt: dateTwoDaysAgo
    },
    {
      id: 'prod-9',
      userId: demoUserId,
      name: 'Gaseosa Coca Cola 500ml',
      category: 'Bebidas',
      quantity: 2, // Alerta stock bajo
      costPrice: 2.20,
      salePrice: 3.00,
      minStock: 8,
      unit: 'unid',
      createdAt: dateTwoDaysAgo,
      updatedAt: dateTwoDaysAgo
    },
    {
      id: 'prod-10',
      userId: demoUserId,
      name: 'Galletas Casino Rellena (Paquete 6u)',
      category: 'Snacks & Golosinas',
      quantity: 22,
      costPrice: 2.80,
      salePrice: 4.20,
      minStock: 6,
      unit: 'paq',
      createdAt: dateTwoDaysAgo,
      updatedAt: dateTwoDaysAgo
    },
    {
      id: 'prod-11',
      userId: demoUserId,
      name: 'Detergente Bolívar Blanco 900g',
      category: 'Limpieza',
      quantity: 10,
      costPrice: 6.80,
      salePrice: 8.90,
      minStock: 5,
      unit: 'unid',
      createdAt: dateTwoDaysAgo,
      updatedAt: dateTwoDaysAgo
    },
    {
      id: 'prod-12',
      userId: demoUserId,
      name: 'Papel Higiénico Suave Doble Hoja x4',
      category: 'Limpieza',
      quantity: 1, // Alerta stock bajo
      costPrice: 4.00,
      salePrice: 5.80,
      minStock: 6,
      unit: 'paq',
      createdAt: dateTwoDaysAgo,
      updatedAt: dateTwoDaysAgo
    }
  ];

  const demoSales: Sale[] = [
    {
      id: 'sale-1',
      userId: demoUserId,
      code: 'V-00101',
      items: [
        { productId: 'prod-1', productName: 'Arroz Extra Costeño 1kg', quantity: 2, costPrice: 3.80, unitPrice: 4.80, subtotal: 9.60 },
        { productId: 'prod-2', productName: 'Aceite Primor Premium 900ml', quantity: 1, costPrice: 7.20, unitPrice: 9.00, subtotal: 9.00 }
      ],
      totalAmount: 18.60,
      totalCost: 14.80,
      profit: 3.80,
      paymentMethod: 'efectivo',
      amountReceived: 20.00,
      changeGiven: 1.40,
      customerNote: 'Vecina doña Rosa',
      createdAt: dateYesterday
    },
    {
      id: 'sale-2',
      userId: demoUserId,
      code: 'V-00102',
      items: [
        { productId: 'prod-7', productName: 'Pan Francés fresco (docena)', quantity: 1, costPrice: 2.00, unitPrice: 3.00, subtotal: 3.00 },
        { productId: 'prod-4', productName: 'Leche Gloria Azul 400g', quantity: 2, costPrice: 3.50, unitPrice: 4.50, subtotal: 9.00 }
      ],
      totalAmount: 12.00,
      totalCost: 9.00,
      profit: 3.00,
      paymentMethod: 'efectivo',
      amountReceived: 15.00,
      changeGiven: 3.00,
      customerNote: '',
      createdAt: dateToday2
    },
    {
      id: 'sale-3',
      userId: demoUserId,
      code: 'V-00103',
      items: [
        { productId: 'prod-8', productName: 'Gaseosa Inca Kola 1.5L', quantity: 1, costPrice: 5.50, unitPrice: 7.50, subtotal: 7.50 },
        { productId: 'prod-10', productName: 'Galletas Casino Rellena (Paquete 6u)', quantity: 1, costPrice: 2.80, unitPrice: 4.20, subtotal: 4.20 }
      ],
      totalAmount: 11.70,
      totalCost: 8.30,
      profit: 3.40,
      paymentMethod: 'efectivo',
      amountReceived: 20.00,
      changeGiven: 8.30,
      createdAt: dateToday1
    }
  ];

  const demoCash: CashMovement[] = [
    {
      id: 'cash-1',
      userId: demoUserId,
      type: 'gasto',
      category: 'mercaderia',
      amount: 120.00,
      description: 'Compra de bolsas y mercadería fresca en mercado mayorista',
      date: dateYesterday,
      createdAt: dateYesterday
    },
    {
      id: 'cash-2',
      userId: demoUserId,
      type: 'ingreso',
      category: 'venta',
      amount: 18.60,
      description: 'Venta #V-00101',
      date: dateYesterday,
      saleId: 'sale-1',
      createdAt: dateYesterday
    },
    {
      id: 'cash-3',
      userId: demoUserId,
      type: 'gasto',
      category: 'servicios',
      amount: 45.00,
      description: 'Recibo de luz del local comercial',
      date: dateToday2,
      createdAt: dateToday2
    },
    {
      id: 'cash-4',
      userId: demoUserId,
      type: 'ingreso',
      category: 'venta',
      amount: 12.00,
      description: 'Venta #V-00102',
      date: dateToday2,
      saleId: 'sale-2',
      createdAt: dateToday2
    },
    {
      id: 'cash-5',
      userId: demoUserId,
      type: 'ingreso',
      category: 'venta',
      amount: 11.70,
      description: 'Venta #V-00103',
      date: dateToday1,
      saleId: 'sale-3',
      createdAt: dateToday1
    }
  ];

  return {
    users: [demoUser],
    products: demoProducts,
    sales: demoSales,
    cashMovements: demoCash
  };
}

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.loadData();
  }

  private loadData(): DatabaseSchema {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (err) {
      console.error('Error reading database file, resetting to seed:', err);
    }
    const seed = getInitialSeedData();
    this.persistSync(seed);
    return seed;
  }

  private persistSync(dataToSave: DatabaseSchema = this.data) {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const tmpPath = `${DB_FILE}.tmp`;
      fs.writeFileSync(tmpPath, JSON.stringify(dataToSave, null, 2), 'utf-8');
      fs.renameSync(tmpPath, DB_FILE);
    } catch (err) {
      console.error('Error persisting database:', err);
    }
  }

  // --- Users & Auth ---
  public findUserByEmail(email: string): StoredUser | undefined {
    return this.data.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  public findUserById(id: string): StoredUser | undefined {
    return this.data.users.find(u => u.id === id);
  }

  public createUser(userData: {
    email: string;
    password: string;
    name: string;
    businessName: string;
    businessType: BusinessType;
    currency?: string;
    phone?: string;
  }): User {
    const { hash, salt } = hashPassword(userData.password);
    const newUser: StoredUser = {
      id: `user-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      email: userData.email.toLowerCase().trim(),
      name: userData.name.trim(),
      businessName: userData.businessName.trim(),
      businessType: userData.businessType,
      currency: userData.currency || 'S/.',
      phone: userData.phone?.trim() || '',
      createdAt: new Date().toISOString(),
      passwordHash: hash,
      salt
    };

    this.data.users.push(newUser);

    // Seed default common starter products for a new business so it's not totally empty!
    const defaultProducts: Omit<Product, 'id' | 'userId' | 'createdAt' | 'updatedAt'>[] = [
      { name: 'Producto de Muestra 1', category: 'General', quantity: 20, costPrice: 5.0, salePrice: 7.5, minStock: 5, unit: 'unid' },
      { name: 'Producto de Muestra 2', category: 'General', quantity: 15, costPrice: 10.0, salePrice: 14.0, minStock: 4, unit: 'unid' }
    ];

    const now = new Date().toISOString();
    defaultProducts.forEach((p, index) => {
      this.data.products.push({
        ...p,
        id: `prod-${Date.now()}-${index}`,
        userId: newUser.id,
        createdAt: now,
        updatedAt: now
      });
    });

    this.persistSync();

    const { passwordHash: _, salt: __, ...cleanUser } = newUser;
    return cleanUser;
  }

  public updateUser(userId: string, updates: Partial<Pick<User, 'businessName' | 'name' | 'currency' | 'phone' | 'businessType'>>): User | null {
    const user = this.data.users.find(u => u.id === userId);
    if (!user) return null;
    if (updates.businessName !== undefined) user.businessName = updates.businessName;
    if (updates.name !== undefined) user.name = updates.name;
    if (updates.currency !== undefined) user.currency = updates.currency;
    if (updates.phone !== undefined) user.phone = updates.phone;
    if (updates.businessType !== undefined) user.businessType = updates.businessType;
    this.persistSync();
    const { passwordHash: _, salt: __, ...cleanUser } = user;
    return cleanUser;
  }

  // --- Products ---
  public getProducts(userId: string, filter?: { search?: string; category?: string; lowStockOnly?: boolean }): Product[] {
    let prods = this.data.products.filter(p => p.userId === userId);

    if (filter?.search) {
      const q = filter.search.toLowerCase().trim();
      prods = prods.filter(p => p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q));
    }

    if (filter?.category && filter.category !== 'all') {
      prods = prods.filter(p => p.category.toLowerCase() === filter.category!.toLowerCase());
    }

    if (filter?.lowStockOnly) {
      prods = prods.filter(p => p.quantity <= p.minStock);
    }

    return prods.sort((a, b) => a.name.localeCompare(b.name));
  }

  public getProductById(userId: string, productId: string): Product | undefined {
    return this.data.products.find(p => p.userId === userId && p.id === productId);
  }

  public createProduct(userId: string, data: Omit<Product, 'id' | 'userId' | 'createdAt' | 'updatedAt'>): Product {
    const now = new Date().toISOString();
    const product: Product = {
      id: `prod-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId,
      name: data.name.trim(),
      category: data.category.trim() || 'General',
      quantity: Number(data.quantity) || 0,
      costPrice: Number(data.costPrice) || 0,
      salePrice: Number(data.salePrice) || 0,
      minStock: Number(data.minStock) || 5,
      unit: data.unit || 'unid',
      createdAt: now,
      updatedAt: now
    };

    this.data.products.push(product);
    this.persistSync();
    return product;
  }

  public updateProduct(userId: string, productId: string, updates: Partial<Omit<Product, 'id' | 'userId' | 'createdAt'>>): Product | null {
    const prod = this.data.products.find(p => p.userId === userId && p.id === productId);
    if (!prod) return null;

    if (updates.name !== undefined) prod.name = updates.name.trim();
    if (updates.category !== undefined) prod.category = updates.category.trim();
    if (updates.quantity !== undefined) prod.quantity = Number(updates.quantity);
    if (updates.costPrice !== undefined) prod.costPrice = Number(updates.costPrice);
    if (updates.salePrice !== undefined) prod.salePrice = Number(updates.salePrice);
    if (updates.minStock !== undefined) prod.minStock = Number(updates.minStock);
    if (updates.unit !== undefined) prod.unit = updates.unit;
    prod.updatedAt = new Date().toISOString();

    this.persistSync();
    return prod;
  }

  public deleteProduct(userId: string, productId: string): boolean {
    const idx = this.data.products.findIndex(p => p.userId === userId && p.id === productId);
    if (idx === -1) return false;
    this.data.products.splice(idx, 1);
    this.persistSync();
    return true;
  }

  // --- Sales ---
  public getSales(userId: string, options?: { limit?: number; period?: string }): Sale[] {
    let sales = this.data.sales.filter(s => s.userId === userId);
    
    if (options?.period) {
      const now = new Date();
      if (options.period === 'today') {
        const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
        sales = sales.filter(s => new Date(s.createdAt).getTime() >= todayStart);
      } else if (options.period === 'week') {
        const weekAgo = now.getTime() - 7 * 24 * 60 * 60 * 1000;
        sales = sales.filter(s => new Date(s.createdAt).getTime() >= weekAgo);
      } else if (options.period === 'month') {
        const monthAgo = now.getTime() - 30 * 24 * 60 * 60 * 1000;
        sales = sales.filter(s => new Date(s.createdAt).getTime() >= monthAgo);
      }
    }

    sales.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    if (options?.limit) {
      sales = sales.slice(0, options.limit);
    }

    return sales;
  }

  public getSaleById(userId: string, saleId: string): Sale | undefined {
    return this.data.sales.find(s => s.userId === userId && s.id === saleId);
  }

  public registerSale(userId: string, saleData: {
    items: { productId: string; quantity: number }[];
    paymentMethod: 'efectivo' | 'transferencia' | 'tarjeta' | 'otro';
    amountReceived?: number;
    customerNote?: string;
  }): { sale: Sale; updatedProducts: Product[] } {
    if (!saleData.items || saleData.items.length === 0) {
      throw new Error('La venta debe tener al menos un producto.');
    }

    // Validate all items exist and have enough stock
    const validatedItems: {
      product: Product;
      quantity: number;
      unitPrice: number;
      costPrice: number;
      subtotal: number;
    }[] = [];

    for (const item of saleData.items) {
      const product = this.getProductById(userId, item.productId);
      if (!product) {
        throw new Error(`Producto con ID ${item.productId} no encontrado.`);
      }
      if (item.quantity <= 0) {
        throw new Error(`La cantidad de ${product.name} debe ser mayor a 0.`);
      }
      if (product.quantity < item.quantity) {
        throw new Error(`Stock insuficiente para "${product.name}". Disponible: ${product.quantity}, solicitado: ${item.quantity}.`);
      }
      validatedItems.push({
        product,
        quantity: item.quantity,
        unitPrice: product.salePrice,
        costPrice: product.costPrice,
        subtotal: Number((item.quantity * product.salePrice).toFixed(2))
      });
    }

    // Deduct stock
    const updatedProducts: Product[] = [];
    const now = new Date().toISOString();

    for (const validItem of validatedItems) {
      validItem.product.quantity -= validItem.quantity;
      validItem.product.updatedAt = now;
      updatedProducts.push(validItem.product);
    }

    const totalAmount = Number(validatedItems.reduce((acc, curr) => acc + curr.subtotal, 0).toFixed(2));
    const totalCost = Number(validatedItems.reduce((acc, curr) => acc + (curr.costPrice * curr.quantity), 0).toFixed(2));
    const profit = Number((totalAmount - totalCost).toFixed(2));

    const changeGiven = saleData.amountReceived && saleData.amountReceived >= totalAmount 
      ? Number((saleData.amountReceived - totalAmount).toFixed(2)) 
      : 0;

    // Create next sale code
    const userSalesCount = this.data.sales.filter(s => s.userId === userId).length;
    const saleCode = `V-${String(userSalesCount + 1).padStart(5, '0')}`;

    const newSale: Sale = {
      id: `sale-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId,
      code: saleCode,
      items: validatedItems.map(item => ({
        productId: item.product.id,
        productName: item.product.name,
        quantity: item.quantity,
        costPrice: item.costPrice,
        unitPrice: item.unitPrice,
        subtotal: item.subtotal
      })),
      totalAmount,
      totalCost,
      profit,
      paymentMethod: saleData.paymentMethod || 'efectivo',
      amountReceived: saleData.amountReceived,
      changeGiven,
      customerNote: saleData.customerNote || '',
      createdAt: now
    };

    this.data.sales.push(newSale);

    // Automatically create Cash Movement for the sale
    const cashMovement: CashMovement = {
      id: `cash-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId,
      type: 'ingreso',
      category: 'venta',
      amount: totalAmount,
      description: `Venta #${saleCode}`,
      date: now,
      saleId: newSale.id,
      createdAt: now
    };

    this.data.cashMovements.push(cashMovement);
    this.persistSync();

    return { sale: newSale, updatedProducts };
  }

  // --- Cash Movements (Gastos e Ingresos) ---
  public getCashMovements(userId: string, options?: { period?: string; type?: 'ingreso' | 'gasto' }): CashMovement[] {
    let movements = this.data.cashMovements.filter(m => m.userId === userId);

    if (options?.type) {
      movements = movements.filter(m => m.type === options.type);
    }

    if (options?.period) {
      const now = new Date();
      if (options.period === 'today') {
        const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
        movements = movements.filter(m => new Date(m.date).getTime() >= todayStart);
      } else if (options.period === 'week') {
        const weekAgo = now.getTime() - 7 * 24 * 60 * 60 * 1000;
        movements = movements.filter(m => new Date(m.date).getTime() >= weekAgo);
      } else if (options.period === 'month') {
        const monthAgo = now.getTime() - 30 * 24 * 60 * 60 * 1000;
        movements = movements.filter(m => new Date(m.date).getTime() >= monthAgo);
      }
    }

    return movements.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  public createCashMovement(userId: string, data: {
    type: 'ingreso' | 'gasto';
    category: string;
    amount: number;
    description: string;
    date?: string;
  }): CashMovement {
    const now = new Date().toISOString();
    const movement: CashMovement = {
      id: `cash-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId,
      type: data.type,
      category: data.category.trim().toLowerCase(),
      amount: Number(data.amount),
      description: data.description.trim(),
      date: data.date || now,
      createdAt: now
    };

    this.data.cashMovements.push(movement);
    this.persistSync();
    return movement;
  }

  public deleteCashMovement(userId: string, movementId: string): boolean {
    const idx = this.data.cashMovements.findIndex(m => m.userId === userId && m.id === movementId);
    if (idx === -1) return false;
    this.data.cashMovements.splice(idx, 1);
    this.persistSync();
    return true;
  }

  // --- Dashboard Stats ---
  public getDashboardStats(userId: string): {
    todaySalesCount: number;
    todaySalesTotal: number;
    todaySalesProfit: number;
    todayUnitsSold: number;
    totalProductsCount: number;
    lowStockProductsCount: number;
    recentSales: Sale[];
    lowStockProducts: Product[];
  } {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

    const allSales = this.data.sales.filter(s => s.userId === userId);
    const todaySales = allSales.filter(s => new Date(s.createdAt).getTime() >= todayStart);

    const todaySalesTotal = Number(todaySales.reduce((acc, curr) => acc + curr.totalAmount, 0).toFixed(2));
    const todaySalesProfit = Number(todaySales.reduce((acc, curr) => acc + curr.profit, 0).toFixed(2));
    const todayUnitsSold = todaySales.reduce((acc, curr) => {
      return acc + curr.items.reduce((sum, item) => sum + item.quantity, 0);
    }, 0);

    const products = this.data.products.filter(p => p.userId === userId);
    const lowStockProducts = products.filter(p => p.quantity <= p.minStock);

    const recentSales = allSales
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 6);

    return {
      todaySalesCount: todaySales.length,
      todaySalesTotal,
      todaySalesProfit,
      todayUnitsSold,
      totalProductsCount: products.length,
      lowStockProductsCount: lowStockProducts.length,
      recentSales,
      lowStockProducts
    };
  }

  // --- Reports (Rendimiento Comercial & Ganancias) ---
  public getReports(userId: string, period: 'today' | 'week' | 'month' | 'all') {
    const now = new Date();
    let startTime = 0;
    let periodLabel = 'Todo el historial';

    if (period === 'today') {
      startTime = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
      periodLabel = 'Hoy';
    } else if (period === 'week') {
      startTime = now.getTime() - 7 * 24 * 60 * 60 * 1000;
      periodLabel = 'Últimos 7 días';
    } else if (period === 'month') {
      startTime = now.getTime() - 30 * 24 * 60 * 60 * 1000;
      periodLabel = 'Últimos 30 días';
    }

    const sales = this.data.sales.filter(
      s => s.userId === userId && new Date(s.createdAt).getTime() >= startTime
    );

    const totalSales = Number(sales.reduce((acc, s) => acc + s.totalAmount, 0).toFixed(2));
    const totalCostOfGoods = Number(sales.reduce((acc, s) => acc + s.totalCost, 0).toFixed(2));
    const grossProfit = Number((totalSales - totalCostOfGoods).toFixed(2));
    const profitMargin = totalSales > 0 ? Number(((grossProfit / totalSales) * 100).toFixed(1)) : 0;
    
    let totalUnitsSold = 0;

    // Top selling products & Sales by Category
    const productSalesMap = new Map<string, { productName: string; quantitySold: number; totalRevenue: number; profit: number }>();
    const categorySalesMap = new Map<string, { revenue: number; quantitySold: number }>();

    // Map products to categories for accuracy
    const productMap = new Map<string, Product>();
    this.data.products.filter(p => p.userId === userId).forEach(p => productMap.set(p.id, p));

    sales.forEach(sale => {
      sale.items.forEach(item => {
        totalUnitsSold += item.quantity;
        const itemProfit = Number(((item.unitPrice - item.costPrice) * item.quantity).toFixed(2));

        // Product mapping
        const existing = productSalesMap.get(item.productId) || {
          productName: item.productName,
          quantitySold: 0,
          totalRevenue: 0,
          profit: 0
        };
        existing.quantitySold += item.quantity;
        existing.totalRevenue = Number((existing.totalRevenue + item.subtotal).toFixed(2));
        existing.profit = Number((existing.profit + itemProfit).toFixed(2));
        productSalesMap.set(item.productId, existing);

        // Category mapping
        const prod = productMap.get(item.productId);
        const cat = prod?.category || 'General';
        const catStat = categorySalesMap.get(cat) || { revenue: 0, quantitySold: 0 };
        catStat.revenue = Number((catStat.revenue + item.subtotal).toFixed(2));
        catStat.quantitySold += item.quantity;
        categorySalesMap.set(cat, catStat);
      });
    });

    const topSellingProducts = Array.from(productSalesMap.values())
      .sort((a, b) => b.totalRevenue - a.totalRevenue)
      .slice(0, 8);

    const salesByCategory = Array.from(categorySalesMap.entries()).map(([category, data]) => ({
      category,
      revenue: data.revenue,
      quantitySold: data.quantitySold,
      percentage: totalSales > 0 ? Number(((data.revenue / totalSales) * 100).toFixed(1)) : 0
    })).sort((a, b) => b.revenue - a.revenue);

    // Timeline for visual charts
    const timelineMap = new Map<string, { sales: number; profit: number; count: number }>();
    sales.forEach(sale => {
      const dateStr = new Date(sale.createdAt).toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit' });
      const current = timelineMap.get(dateStr) || { sales: 0, profit: 0, count: 0 };
      current.sales = Number((current.sales + sale.totalAmount).toFixed(2));
      current.profit = Number((current.profit + sale.profit).toFixed(2));
      current.count += 1;
      timelineMap.set(dateStr, current);
    });

    const timeline = Array.from(timelineMap.entries()).map(([date, val]) => ({
      date,
      sales: val.sales,
      profit: val.profit,
      count: val.count
    }));

    return {
      period,
      periodLabel,
      totalSales,
      totalSalesCount: sales.length,
      totalCostOfGoods,
      grossProfit,
      profitMargin,
      totalUnitsSold,
      topSellingProducts,
      salesByCategory,
      timeline
    };
  }

  // Reset or re-seed demo data
  public resetDemoData(): void {
    const seed = getInitialSeedData();
    this.data = seed;
    this.persistSync(seed);
  }
}

export const db = new Database();
