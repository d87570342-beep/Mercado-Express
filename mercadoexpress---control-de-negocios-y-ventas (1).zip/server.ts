import express from 'express';
import type { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  db,
  createSessionToken,
  getUserIdFromToken,
  verifyPassword
} from './server/db.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface AuthRequest extends Request {
  userId?: string;
}

// Authentication middleware
function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No autorizado. Se requiere token.' });
  }

  const token = authHeader.split(' ')[1];
  const userId = getUserIdFromToken(token);

  if (!userId) {
    return res.status(401).json({ error: 'Sesión expirada o token inválido.' });
  }

  const user = db.findUserById(userId);
  if (!user) {
    return res.status(401).json({ error: 'Usuario no encontrado.' });
  }

  req.userId = userId;
  next();
}

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json());

  // --- AUTH ROUTES ---
  app.post('/api/auth/register', (req: Request, res: Response) => {
    try {
      const { email, password, name, businessName, businessType, currency, phone } = req.body;

      if (!email || !password || !name || !businessName) {
        return res.status(400).json({ error: 'Por favor completa todos los campos requeridos.' });
      }

      if (password.length < 5) {
        return res.status(400).json({ error: 'La contraseña debe tener al menos 5 caracteres.' });
      }

      const existing = db.findUserByEmail(email);
      if (existing) {
        return res.status(400).json({ error: 'Ya existe una cuenta con este correo electrónico.' });
      }

      const user = db.createUser({
        email,
        password,
        name,
        businessName,
        businessType: businessType || 'bodega',
        currency: currency || 'S/.',
        phone
      });

      const token = createSessionToken(user.id);
      return res.status(201).json({ user, token });
    } catch (err: any) {
      console.error('Register error:', err);
      return res.status(500).json({ error: err.message || 'Error al registrar usuario.' });
    }
  });

  app.post('/api/auth/login', (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return res.status(400).json({ error: 'Ingresa correo y contraseña.' });
      }

      const user = db.findUserByEmail(email);
      if (!user) {
        return res.status(401).json({ error: 'Correo o contraseña incorrectos.' });
      }

      const isValid = verifyPassword(password, user.passwordHash, user.salt);
      if (!isValid) {
        return res.status(401).json({ error: 'Correo o contraseña incorrectos.' });
      }

      const token = createSessionToken(user.id);
      const { passwordHash: _, salt: __, ...cleanUser } = user;
      return res.json({ user: cleanUser, token });
    } catch (err: any) {
      console.error('Login error:', err);
      return res.status(500).json({ error: err.message || 'Error al iniciar sesión.' });
    }
  });

  // Direct Owner Session (No Login Screen)
  app.all(['/api/auth/owner-session', '/api/auth/demo'], (_req: Request, res: Response) => {
    try {
      let owner = db.findUserByEmail('demo@mercadoexpress.com');
      if (!owner) {
        db.resetDemoData();
        owner = db.findUserByEmail('demo@mercadoexpress.com');
      }
      if (!owner) {
        return res.status(500).json({ error: 'No se pudo iniciar la sesión del propietario.' });
      }

      const token = createSessionToken(owner.id);
      const { passwordHash: _, salt: __, ...cleanUser } = owner;
      return res.json({ user: cleanUser, token });
    } catch (err: any) {
      return res.status(500).json({ error: 'Error al iniciar sesión del dueño.' });
    }
  });

  // Reset Demo Data
  app.post('/api/auth/demo/reset', (_req: Request, res: Response) => {
    try {
      db.resetDemoData();
      return res.json({ message: 'Datos demo restablecidos exitosamente.' });
    } catch (err: any) {
      return res.status(500).json({ error: 'Error al reiniciar datos.' });
    }
  });

  app.get('/api/auth/me', requireAuth, (req: AuthRequest, res: Response) => {
    const user = db.findUserById(req.userId!);
    if (!user) return res.status(404).json({ error: 'Usuario no encontrado.' });
    const { passwordHash: _, salt: __, ...cleanUser } = user;
    return res.json({ user: cleanUser });
  });

  app.put('/api/auth/profile', requireAuth, (req: AuthRequest, res: Response) => {
    try {
      const { businessName, name, currency, phone, businessType } = req.body;
      const updated = db.updateUser(req.userId!, { businessName, name, currency, phone, businessType });
      if (!updated) return res.status(404).json({ error: 'Usuario no encontrado.' });
      return res.json({ user: updated });
    } catch (err: any) {
      return res.status(500).json({ error: 'Error al actualizar perfil.' });
    }
  });

  // --- PRODUCTS ROUTES ---
  app.get('/api/products', requireAuth, (req: AuthRequest, res: Response) => {
    try {
      const { search, category, lowStockOnly } = req.query;
      const products = db.getProducts(req.userId!, {
        search: typeof search === 'string' ? search : undefined,
        category: typeof category === 'string' ? category : undefined,
        lowStockOnly: lowStockOnly === 'true'
      });
      return res.json({ products });
    } catch (err: any) {
      return res.status(500).json({ error: 'Error al listar productos.' });
    }
  });

  app.post('/api/products', requireAuth, (req: AuthRequest, res: Response) => {
    try {
      const { name, category, quantity, costPrice, salePrice, minStock, unit } = req.body;
      if (!name || name.trim() === '') {
        return res.status(400).json({ error: 'El nombre del producto es obligatorio.' });
      }
      if (salePrice === undefined || Number(salePrice) < 0) {
        return res.status(400).json({ error: 'El precio de venta debe ser un número válido.' });
      }

      const product = db.createProduct(req.userId!, {
        name,
        category: category || 'General',
        quantity: Number(quantity) || 0,
        costPrice: Number(costPrice) || 0,
        salePrice: Number(salePrice) || 0,
        minStock: Number(minStock) || 5,
        unit: unit || 'unid'
      });
      return res.status(201).json({ product });
    } catch (err: any) {
      return res.status(500).json({ error: err.message || 'Error al crear producto.' });
    }
  });

  app.put('/api/products/:id', requireAuth, (req: AuthRequest, res: Response) => {
    try {
      const { id } = req.params;
      const updated = db.updateProduct(req.userId!, id, req.body);
      if (!updated) {
        return res.status(404).json({ error: 'Producto no encontrado.' });
      }
      return res.json({ product: updated });
    } catch (err: any) {
      return res.status(500).json({ error: 'Error al actualizar producto.' });
    }
  });

  app.delete('/api/products/:id', requireAuth, (req: AuthRequest, res: Response) => {
    try {
      const { id } = req.params;
      const success = db.deleteProduct(req.userId!, id);
      if (!success) {
        return res.status(404).json({ error: 'Producto no encontrado.' });
      }
      return res.json({ message: 'Producto eliminado correctamente.' });
    } catch (err: any) {
      return res.status(500).json({ error: 'Error al eliminar producto.' });
    }
  });

  // --- SALES ROUTES ---
  app.get('/api/sales', requireAuth, (req: AuthRequest, res: Response) => {
    try {
      const { period, limit } = req.query;
      const sales = db.getSales(req.userId!, {
        period: typeof period === 'string' ? period : undefined,
        limit: limit ? Number(limit) : undefined
      });
      return res.json({ sales });
    } catch (err: any) {
      return res.status(500).json({ error: 'Error al consultar historial de ventas.' });
    }
  });

  app.get('/api/sales/:id', requireAuth, (req: AuthRequest, res: Response) => {
    try {
      const sale = db.getSaleById(req.userId!, req.params.id);
      if (!sale) return res.status(404).json({ error: 'Venta no encontrada.' });
      return res.json({ sale });
    } catch (err: any) {
      return res.status(500).json({ error: 'Error al obtener venta.' });
    }
  });

  app.post('/api/sales', requireAuth, (req: AuthRequest, res: Response) => {
    try {
      const { items, paymentMethod, amountReceived, customerNote } = req.body;
      const result = db.registerSale(req.userId!, {
        items,
        paymentMethod: paymentMethod || 'efectivo',
        amountReceived: amountReceived ? Number(amountReceived) : undefined,
        customerNote
      });
      return res.status(201).json(result);
    } catch (err: any) {
      return res.status(400).json({ error: err.message || 'Error al registrar la venta.' });
    }
  });

  // --- CASH FLOW (GASTOS E INGRESOS) ROUTES ---
  app.get('/api/cash', requireAuth, (req: AuthRequest, res: Response) => {
    try {
      const { period, type } = req.query;
      const movements = db.getCashMovements(req.userId!, {
        period: typeof period === 'string' ? period : undefined,
        type: type === 'ingreso' || type === 'gasto' ? type : undefined
      });
      return res.json({ movements });
    } catch (err: any) {
      return res.status(500).json({ error: 'Error al consultar caja.' });
    }
  });

  app.post('/api/cash', requireAuth, (req: AuthRequest, res: Response) => {
    try {
      const { type, category, amount, description, date } = req.body;
      if (!type || !amount || Number(amount) <= 0 || !description) {
        return res.status(400).json({ error: 'Indica tipo, monto mayor a 0 y descripción.' });
      }
      const movement = db.createCashMovement(req.userId!, {
        type: type === 'ingreso' ? 'ingreso' : 'gasto',
        category: category || (type === 'gasto' ? 'otros' : 'venta'),
        amount: Number(amount),
        description,
        date
      });
      return res.status(201).json({ movement });
    } catch (err: any) {
      return res.status(500).json({ error: 'Error al registrar movimiento de caja.' });
    }
  });

  app.delete('/api/cash/:id', requireAuth, (req: AuthRequest, res: Response) => {
    try {
      const success = db.deleteCashMovement(req.userId!, req.params.id);
      if (!success) return res.status(404).json({ error: 'Movimiento no encontrado.' });
      return res.json({ message: 'Movimiento eliminado.' });
    } catch (err: any) {
      return res.status(500).json({ error: 'Error al eliminar movimiento.' });
    }
  });

  // --- DASHBOARD & REPORTS ROUTES ---
  app.get('/api/dashboard/stats', requireAuth, (req: AuthRequest, res: Response) => {
    try {
      const stats = db.getDashboardStats(req.userId!);
      return res.json({ stats });
    } catch (err: any) {
      return res.status(500).json({ error: 'Error al cargar estadísticas del panel.' });
    }
  });

  app.get('/api/reports', requireAuth, (req: AuthRequest, res: Response) => {
    try {
      const period = (req.query.period as 'today' | 'week' | 'month' | 'all') || 'today';
      const report = db.getReports(req.userId!, period);
      return res.json({ report });
    } catch (err: any) {
      return res.status(500).json({ error: 'Error al generar reporte.' });
    }
  });

  // --- VITE MIDDLEWARE / STATIC ASSETS ---
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(process.cwd(), 'dist/index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MercadoExpress Server running on port ${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
