import React from 'react';
import { AppProvider, useApp } from './context/AppContext.tsx';
import { Header } from './components/Header.tsx';
import { Navigation } from './components/Navigation.tsx';
import { DashboardView } from './views/DashboardView.tsx';
import { ProductsView } from './views/ProductsView.tsx';
import { SalesView } from './views/SalesView.tsx';
import { CashFlowView } from './views/CashFlowView.tsx';
import { QuickSaleModal } from './components/QuickSaleModal.tsx';
import { ProductModal } from './components/ProductModal.tsx';
import { AlertCircle } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { activeTab, quickModal, setQuickModal, error } = useApp();

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col selection:bg-emerald-200">
      {/* Top Header */}
      <Header />

      {/* Navigation (Desktop horizontal bar & mobile responsive) */}
      <Navigation />

      {/* Global Firestore Error Notification if any */}
      {error && (
        <div className="fixed top-18 right-4 z-50 bg-rose-900/95 backdrop-blur-xs text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 text-xs font-bold border border-rose-700 animate-in fade-in slide-in-from-top-3">
          <AlertCircle className="w-4 h-4 text-rose-300 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-5 sm:py-6">
        {activeTab === 'dashboard' && <DashboardView />}
        {activeTab === 'sales' && <SalesView />}
        {activeTab === 'products' && <ProductsView />}
        {activeTab === 'cashflow' && <CashFlowView />}
      </main>

      {/* Global Quick Action Modals */}
      <QuickSaleModal
        isOpen={quickModal === 'sale'}
        onClose={() => setQuickModal(null)}
      />
      <ProductModal
        isOpen={quickModal === 'product'}
        productToEdit={null}
        onClose={() => setQuickModal(null)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
