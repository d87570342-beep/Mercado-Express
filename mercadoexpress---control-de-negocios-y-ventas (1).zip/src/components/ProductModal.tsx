import React, { useState, useEffect } from 'react';
import { X, Package, AlertCircle, Check } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { Product, ProductCategory } from '../types.ts';

interface ProductModalProps {
  productToEdit?: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

const CATEGORIES: ProductCategory[] = [
  'Abarrotes',
  'Bebidas y Licores',
  'Lácteos y Huevos',
  'Limpieza y Aseo',
  'Snacks y Golosinas',
  'Frutas y Verduras',
  'Panadería y Embutidos',
  'Cuidado Personal',
  'Otros',
];

export const ProductModal: React.FC<ProductModalProps> = ({ 
  productToEdit, 
  isOpen, 
  onClose 
}) => {
  const { addProduct, updateProduct } = useApp();
  const [name, setName] = useState('');
  const [category, setCategory] = useState<ProductCategory>('Abarrotes');
  const [stock, setStock] = useState<string>('10');
  const [purchasePrice, setPurchasePrice] = useState<string>('');
  const [salePrice, setSalePrice] = useState<string>('');
  const [minStock, setMinStock] = useState<string>('5');
  const [error, setError] = useState<string | null>(null);
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (productToEdit) {
      setName(productToEdit.name);
      setCategory(productToEdit.category);
      setStock(productToEdit.stock.toString());
      setPurchasePrice(productToEdit.purchasePrice.toString());
      setSalePrice(productToEdit.salePrice.toString());
      setMinStock((productToEdit.minStock || 5).toString());
    } else {
      setName('');
      setCategory('Abarrotes');
      setStock('10');
      setPurchasePrice('');
      setSalePrice('');
      setMinStock('5');
    }
    setError(null);
    setSaveSuccessMessage(null);
  }, [productToEdit, isOpen]);

  if (!isOpen) return null;

  const numPurchase = parseFloat(purchasePrice) || 0;
  const numSale = parseFloat(salePrice) || 0;
  const unitProfit = numSale - numPurchase;
  const profitMargin = numSale > 0 ? ((unitProfit / numSale) * 100).toFixed(0) : '0';
  const isEditing = !!productToEdit;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaveSuccessMessage(null);

    if (!name.trim()) {
      setError('Por favor escribe el nombre del producto.');
      return;
    }
    if (isNaN(numPurchase) || numPurchase < 0) {
      setError('Ingresa un precio de compra válido.');
      return;
    }
    if (isNaN(numSale) || numSale <= 0) {
      setError('Ingresa un precio de venta mayor a 0.');
      return;
    }
    const parsedStock = parseInt(stock, 10);
    if (isNaN(parsedStock) || parsedStock < 0) {
      setError('Ingresa una cantidad de stock válida.');
      return;
    }
    const parsedMinStock = parseInt(minStock, 10) || 5;

    setIsSaving(true);
    try {
      if (isEditing && productToEdit) {
        await updateProduct(productToEdit.id, {
          name: name.trim(),
          category,
          stock: parsedStock,
          purchasePrice: numPurchase,
          salePrice: numSale,
          minStock: parsedMinStock,
        });
        setSaveSuccessMessage('Guardado confirmado en Firestore');
      } else {
        await addProduct({
          name: name.trim(),
          category,
          stock: parsedStock,
          purchasePrice: numPurchase,
          salePrice: numSale,
          minStock: parsedMinStock,
        });
        setSaveSuccessMessage('Guardado confirmado en Firestore');
      }
      setIsSaving(false);
      setTimeout(() => {
        onClose();
      }, 1000);
    } catch (err: any) {
      setIsSaving(false);
      const codeStr = err?.code ? `[Código: ${err.code}] ` : '';
      const msgStr = err?.message || String(err);
      setError(`Error al guardar en Cloud Firestore: ${codeStr}${msgStr}`);
    }
  };

  return (
    <div 
      id="product-modal-backdrop" 
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
    >
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Encabezado */}
        <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600/30 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Package className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">
                {isEditing ? 'Editar Producto' : 'Nuevo Producto'}
              </h3>
              <p className="text-xs text-slate-400">
                {isEditing ? productToEdit?.name : 'Formulario simplificado para base de datos'}
              </p>
            </div>
          </div>
          <button
            id="close-product-modal-btn"
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Formulario */}
        <form id="product-form" onSubmit={handleSubmit} className="p-5 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs font-medium flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {saveSuccessMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{saveSuccessMessage}</span>
            </div>
          )}

          {/* Nombre y Categoría */}
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1" htmlFor="input-product-name">
                Nombre del Producto *
              </label>
              <input
                id="input-product-name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="ej: Leche Gloria Azul 400g, Arroz Costeño 1kg..."
                className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium text-slate-800"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1" htmlFor="select-product-category">
                  Categoría
                </label>
                <select
                  id="select-product-category"
                  value={category}
                  onChange={(e) => setCategory(e.target.value as ProductCategory)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white font-medium text-slate-800"
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-700" htmlFor="input-product-stock">
                    Stock {isEditing ? 'Actual' : 'Inicial'}
                  </label>
                  <button
                    type="button"
                    onClick={() => setStock('0')}
                    className="text-[10px] text-amber-700 hover:text-amber-900 font-bold bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200 cursor-pointer"
                  >
                    Borrar a 0
                  </button>
                </div>
                <input
                  id="input-product-stock"
                  type="number"
                  min="0"
                  required
                  value={stock}
                  onChange={(e) => setStock(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-slate-800"
                />
              </div>
            </div>
          </div>

          {/* PRECIOS: COMPRA Y VENTA */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            {/* Precio en el que me dan */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <label className="block text-xs font-bold text-slate-700 mb-1" htmlFor="input-purchase-price">
                Precio que te dan (Costo)
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-2.5 flex items-center text-xs font-bold text-slate-400">
                  S/
                </span>
                <input
                  id="input-purchase-price"
                  type="number"
                  step="any"
                  min="0"
                  required
                  value={purchasePrice}
                  onChange={(e) => setPurchasePrice(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-7 pr-2.5 py-2 text-sm rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-slate-800"
                />
              </div>
              <span className="text-[10px] text-slate-500 block mt-1">Costo unitario</span>
            </div>

            {/* Precio a vender */}
            <div className="bg-emerald-50/60 p-3 rounded-xl border border-emerald-300">
              <label className="block text-xs font-bold text-emerald-900 mb-1" htmlFor="input-sale-price">
                Precio a vender (Público)
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-2.5 flex items-center text-xs font-bold text-emerald-600">
                  S/
                </span>
                <input
                  id="input-sale-price"
                  type="number"
                  step="any"
                  min="0"
                  required
                  value={salePrice}
                  onChange={(e) => setSalePrice(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-7 pr-2.5 py-2 text-sm rounded-lg border-2 border-emerald-500 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600 font-black text-emerald-950"
                />
              </div>
              <span className="text-[10px] text-emerald-700 font-medium block mt-1">Precio de venta</span>
            </div>
          </div>

          {/* Ganancia por unidad */}
          <div className="px-3 py-2 bg-slate-100/80 rounded-xl flex items-center justify-between text-xs font-medium">
            <span className="text-slate-600">Ganancia por unidad:</span>
            <div className="flex items-center gap-1.5">
              <span className={`font-bold ${unitProfit >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                {unitProfit >= 0 ? `+S/ ${unitProfit.toFixed(2)}` : `-S/ ${Math.abs(unitProfit).toFixed(2)}`}
              </span>
              <span className="bg-white border border-slate-200 px-1.5 py-0.5 rounded text-[10px] font-bold text-slate-700">
                {profitMargin}% margen
              </span>
            </div>
          </div>

          {/* Botones de acción */}
          <div className="pt-2 flex gap-2.5">
            <button
              id="cancel-product-btn"
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition text-xs cursor-pointer"
            >
              Cancelar
            </button>
            <button
              id="save-product-btn"
              type="submit"
              disabled={isSaving}
              className="flex-1 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-70 text-white font-bold rounded-xl shadow-xs transition text-xs flex items-center justify-center gap-1.5 active:scale-[0.99] cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>{isSaving ? 'Guardando en Firestore...' : isEditing ? 'Guardar Cambios' : 'Guardar Producto'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
