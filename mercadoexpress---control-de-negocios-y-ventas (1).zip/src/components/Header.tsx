import React, { useState } from 'react';
import { Store, AlertTriangle, ShieldCheck, Edit3, X, Check } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';

export const Header: React.FC = () => {
  const { user, updateBodegaInfo, metrics, setActiveTab } = useApp();
  const [isEditingStore, setIsEditingStore] = useState(false);
  const [tempBodegaName, setTempBodegaName] = useState(user.bodegaName || '');
  const [tempOwnerName, setTempOwnerName] = useState(user.name || '');

  const handleSaveStoreInfo = (e: React.FormEvent) => {
    e.preventDefault();
    if (tempBodegaName.trim()) {
      updateBodegaInfo({
        bodegaName: tempBodegaName.trim(),
        name: tempOwnerName.trim() || user.name,
      });
      setIsEditingStore(false);
    }
  };

  return (
    <>
      <header id="app-header" className="bg-emerald-700 text-white shadow-md sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          {/* Brand & Store name */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white text-emerald-700 flex items-center justify-center font-bold shadow-sm shrink-0">
              <Store className="w-6 h-6 text-emerald-700" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-tight text-white">MercadoExpress</span>
                <span className="bg-emerald-800 text-emerald-100 text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                  Panel Dueño
                </span>
              </div>
              <div className="flex items-center gap-1.5 mt-0.5">
                <p className="text-xs text-emerald-100 font-medium truncate max-w-[150px] sm:max-w-xs">
                  {user.bodegaName}
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setTempBodegaName(user.bodegaName);
                    setTempOwnerName(user.name);
                    setIsEditingStore(true);
                  }}
                  className="text-emerald-300 hover:text-white transition p-0.5 cursor-pointer"
                  title="Editar nombre de mi bodega"
                >
                  <Edit3 className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>

          {/* Right side controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Low stock quick notification button */}
            {metrics.lowStockCount > 0 && (
              <button
                id="header-low-stock-alert"
                onClick={() => setActiveTab('products')}
                className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 px-2.5 py-1.5 rounded-lg text-xs font-bold transition shadow-sm animate-pulse cursor-pointer"
                title={`${metrics.lowStockCount} productos con poco stock`}
              >
                <AlertTriangle className="w-4 h-4 text-slate-950 shrink-0" />
                <span className="hidden sm:inline">Poco stock:</span>
                <span className="bg-amber-950 text-amber-100 text-[11px] font-black px-1.5 py-0.2 rounded">
                  {metrics.lowStockCount}
                </span>
              </button>
            )}

            {/* Owner status badge */}
            <div className="flex items-center gap-2 pl-2 border-l border-emerald-600/60">
              <div className="text-right">
                <div className="text-xs font-bold text-white flex items-center justify-end gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                  <span>{user.name}</span>
                </div>
                <div className="text-[10px] text-emerald-200 font-semibold">
                  Acceso Total (Dueño)
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Modal para cambiar nombre de la bodega y dueño */}
      {isEditingStore && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-sm overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <Store className="w-4 h-4 text-emerald-600" />
                  Datos de mi Bodega
                </h3>
                <button
                  onClick={() => setIsEditingStore(false)}
                  className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveStoreInfo} className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1" htmlFor="edit-bodega-name">
                    Nombre de la Bodega o Minimarket:
                  </label>
                  <input
                    id="edit-bodega-name"
                    type="text"
                    required
                    value={tempBodegaName}
                    onChange={(e) => setTempBodegaName(e.target.value)}
                    placeholder="Ej: Bodega San Martín"
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1" htmlFor="edit-owner-name">
                    Nombre del Propietario / Dueño:
                  </label>
                  <input
                    id="edit-owner-name"
                    type="text"
                    value={tempOwnerName}
                    onChange={(e) => setTempOwnerName(e.target.value)}
                    placeholder="Ej: Don Pedro Gómez"
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium text-slate-900"
                  />
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsEditingStore(false)}
                    className="flex-1 py-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                    Guardar
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
