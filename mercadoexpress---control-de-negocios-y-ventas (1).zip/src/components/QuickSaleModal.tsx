import React, { useState, useMemo, useEffect } from 'react';
import { 
  X, 
  ShoppingCart, 
  Search, 
  Plus, 
  Minus, 
  Check, 
  AlertCircle, 
  Coins, 
  ArrowRight, 
  TrendingUp 
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { Product } from '../types.ts';

interface QuickSaleModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedProduct?: Product | null;
}

export const QuickSaleModal: React.FC<QuickSaleModalProps> = ({
  isOpen,
  onClose,
  preselectedProduct,
}) => {
  const { products, recordSale } = useApp();
  const [selectedProductId, setSelectedProductId] = useState<string>(preselectedProduct?.id || '');
  const [searchTerm, setSearchTerm] = useState('');
  const [quantity, setQuantity] = useState<number>(1);
  const [amountPaid, setAmountPaid] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [successInfo, setSuccessInfo] = useState<{ total: number; change: number; productName: string } | null>(null);

  useEffect(() => {
    if (preselectedProduct) {
      setSelectedProductId(preselectedProduct.id);
    } else if (products.length > 0 && !selectedProductId) {
      setSelectedProductId(products[0].id);
    }
    setQuantity(1);
    setAmountPaid('');
    setError(null);
    setSuccessInfo(null);
  }, [preselectedProduct, isOpen]);

  const selectedProduct = useMemo(() => {
    return products.find((p) => p.id === selectedProductId) || null;
  }, [products, selectedProductId]);

  const filteredProducts = useMemo(() => {
    if (!searchTerm.trim()) return products;
    const term = searchTerm.toLowerCase();
    return products.filter(
      (p) => p.name.toLowerCase().includes(term) || p.category.toLowerCase().includes(term)
    );
  }, [products, searchTerm]);

  if (!isOpen) return null;

  const totalSale = selectedProduct ? selectedProduct.salePrice * quantity : 0;
  const numPaid = amountPaid.trim() === '' ? totalSale : (parseFloat(amountPaid) || 0);
  const changeToGive = numPaid > totalSale ? numPaid - totalSale : 0;
  const isShortPayment = numPaid < totalSale && amountPaid.trim() !== '';
  const shortAmount = isShortPayment ? totalSale - numPaid : 0;
  const unitProfit = selectedProduct ? selectedProduct.salePrice - selectedProduct.purchasePrice : 0;

  const handleIncrement = () => {
    if (selectedProduct && quantity < selectedProduct.stock) {
      setQuantity((q) => q + 1);
    }
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity((q) => q - 1);
    }
  };

  const handleQuickPayOption = (value: number) => {
    setAmountPaid(value.toFixed(2));
  };

  const handleConfirmSale = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!selectedProduct) {
      setError('Seleccione un producto para vender.');
      return;
    }
    if (quantity <= 0) {
      setError('La cantidad debe ser al menos 1.');
      return;
    }
    if (selectedProduct.stock < quantity) {
      setError(`Stock insuficiente. Solo quedan ${selectedProduct.stock} unidades.`);
      return;
    }

    const pay = amountPaid.trim() === '' ? totalSale : (parseFloat(amountPaid) || totalSale);
    const result = recordSale({
      productId: selectedProduct.id,
      quantity,
      amountPaid: pay,
    });

    if (result.success) {
      setSuccessInfo({
        total: totalSale,
        change: changeToGive,
        productName: selectedProduct.name,
      });
    } else {
      setError(result.error || 'Error al procesar la venta.');
    }
  };

  const handleNewSaleReset = () => {
    setSuccessInfo(null);
    setQuantity(1);
    setAmountPaid('');
    setError(null);
  };

  return (
    <div
      id="quick-sale-modal-backdrop"
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-hidden"
    >
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] flex flex-col overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-4 py-3 bg-emerald-700 text-white flex items-center justify-between shrink-0 shadow-xs">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-800 flex items-center justify-center">
              <ShoppingCart className="w-4 h-4 text-emerald-200" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base leading-tight">
                Vender Producto
              </h3>
              <p className="text-[10px] text-emerald-100 font-medium">
                Registra la venta e ingresa el dinero a caja
              </p>
            </div>
          </div>
          <button
            id="close-sale-modal-btn"
            type="button"
            onClick={onClose}
            className="text-emerald-100 hover:text-white p-1 rounded-lg hover:bg-emerald-800/80 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        {successInfo ? (
          <div className="p-5 overflow-y-auto flex-1 text-center space-y-4">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <Check className="w-8 h-8 stroke-[3]" />
            </div>
            <div>
              <h4 className="text-lg font-black text-slate-900">¡Venta Registrada!</h4>
              <p className="text-xs text-slate-600 mt-0.5">
                Se actualizó el stock y se registró en el historial de ventas y ganancias.
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-left max-w-xs mx-auto space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Producto:</span>
                <span className="font-bold text-slate-800 text-right truncate max-w-[170px]">
                  {successInfo.productName}
                </span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Cantidad:</span>
                <span className="font-bold text-slate-800">{quantity} und.</span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-2 text-sm font-black text-slate-900">
                <span>Total Cobrado:</span>
                <span className="text-emerald-700">S/ {successInfo.total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-600 font-semibold">
                <span>Vuelto entregado:</span>
                <span className="text-slate-900 font-bold">S/ {successInfo.change.toFixed(2)}</span>
              </div>
            </div>

            <div className="pt-2 flex gap-2">
              <button
                id="sale-success-close-btn"
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl transition text-xs cursor-pointer"
              >
                Cerrar
              </button>
              <button
                id="sale-success-another-btn"
                type="button"
                onClick={handleNewSaleReset}
                className="flex-1 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition text-xs shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Otra Venta</span>
              </button>
            </div>
          </div>
        ) : (
          <form id="quick-sale-form" onSubmit={handleConfirmSale} className="flex flex-col flex-1 overflow-hidden">
            <div className="p-3.5 sm:p-4 overflow-y-auto flex-1 space-y-3">
              {error && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs font-medium flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* Selector de Producto */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <label className="block text-xs font-bold text-slate-700" htmlFor="sale-search-input">
                  Seleccionar Producto
                </label>
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    id="sale-search-input"
                    type="text"
                    placeholder="Buscar producto..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                  />
                </div>
                <select
                  id="sale-product-select"
                  value={selectedProductId}
                  onChange={(e) => {
                    setSelectedProductId(e.target.value);
                    setQuantity(1);
                  }}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-slate-900 bg-white"
                >
                  {filteredProducts.map((p) => (
                    <option key={p.id} value={p.id} disabled={p.stock <= 0}>
                      {p.name} - S/ {p.salePrice.toFixed(2)} ({p.stock <= 0 ? 'SIN STOCK' : `Stock: ${p.stock}`})
                    </option>
                  ))}
                </select>
              </div>

              {/* Tarjeta del Producto Seleccionado */}
              {selectedProduct && (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block">
                        {selectedProduct.category}
                      </span>
                      <h4 className="font-black text-slate-900 text-sm sm:text-base leading-tight truncate">
                        {selectedProduct.name}
                      </h4>
                    </div>
                    <span
                      className={`shrink-0 text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                        selectedProduct.stock <= 0
                          ? 'bg-rose-100 text-rose-800'
                          : selectedProduct.stock <= selectedProduct.minStock
                          ? 'bg-amber-100 text-amber-900'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {selectedProduct.stock <= 0 ? 'Sin stock' : `Stock: ${selectedProduct.stock} und.`}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1.5 border-t border-slate-200 text-center">
                    <div className="bg-emerald-50/80 p-2 rounded-lg border border-emerald-300 shadow-2xs">
                      <span className="text-[9px] font-bold text-emerald-800 uppercase tracking-wider block">
                        Precio de venta:
                      </span>
                      <span className="text-sm font-black text-emerald-700">
                        S/ {selectedProduct.salePrice.toFixed(2)}
                      </span>
                    </div>

                    <div className="bg-teal-50/80 p-2 rounded-lg border border-teal-200 shadow-2xs">
                      <span className="text-[9px] font-bold text-teal-800 uppercase tracking-wider block flex items-center justify-center gap-0.5">
                        <TrendingUp className="w-2.5 h-2.5" />
                        Ganancia / und:
                      </span>
                      <span className="text-sm font-black text-teal-700">
                        +S/ {unitProfit.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Cantidad a Vender */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Cantidad a Vender:
                </label>
                <div className="flex items-center gap-2">
                  <button
                    id="sale-qty-minus-btn"
                    type="button"
                    onClick={handleDecrement}
                    disabled={quantity <= 1}
                    className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-800 flex items-center justify-center font-bold text-base transition active:scale-95 cursor-pointer"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <div className="flex-1 text-center">
                    <input
                      id="sale-qty-input"
                      type="number"
                      min="1"
                      max={selectedProduct?.stock || 999}
                      value={quantity}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10);
                        if (!isNaN(val) && val >= 1) {
                          setQuantity(val);
                        }
                      }}
                      className="w-full text-center py-1.5 text-xl font-black text-slate-900 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                    <span className="text-[10px] text-slate-500 font-semibold">unidades</span>
                  </div>
                  <button
                    id="sale-qty-plus-btn"
                    type="button"
                    onClick={handleIncrement}
                    disabled={!selectedProduct || quantity >= selectedProduct.stock}
                    className="w-10 h-10 rounded-xl bg-emerald-100 hover:bg-emerald-200 disabled:opacity-40 text-emerald-800 flex items-center justify-center font-bold text-base transition active:scale-95 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Total a Cobrar */}
              <div className="p-3 bg-slate-900 text-white rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                    Total a Cobrar
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {quantity} x S/ {selectedProduct?.salePrice.toFixed(2)}
                  </span>
                </div>
                <div className="text-2xl font-black text-emerald-400">
                  S/ {totalSale.toFixed(2)}
                </div>
              </div>

              {/* Paga con y vuelto */}
              <div className="space-y-2 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1" htmlFor="sale-amount-paid">
                    <Coins className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Paga con:</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => handleQuickPayOption(totalSale)}
                    className="text-[10px] text-emerald-700 font-bold hover:underline cursor-pointer"
                  >
                    Pago Exacto
                  </button>
                </div>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-xs font-bold text-slate-400 pointer-events-none">
                    S/
                  </span>
                  <input
                    id="sale-amount-paid"
                    type="number"
                    step="any"
                    value={amountPaid}
                    onChange={(e) => setAmountPaid(e.target.value)}
                    placeholder={`Ej: ${totalSale.toFixed(2)} o billete de 10, 20...`}
                    className="w-full pl-8 pr-3 py-2 text-sm rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-slate-900"
                  />
                </div>
                {/* Atajos de billetes */}
                <div className="flex flex-wrap gap-1">
                  {[totalSale, 5, 10, 20, 50].map((val, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleQuickPayOption(val)}
                      className={`px-2 py-1 rounded text-[10px] font-bold border transition cursor-pointer ${
                        parseFloat(amountPaid) === val
                          ? 'bg-slate-900 text-white border-slate-900'
                          : idx === 0
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {idx === 0 ? `Exacto (S/ ${val.toFixed(2)})` : `S/ ${val}`}
                    </button>
                  ))}
                </div>
                {/* Vuelto */}
                {changeToGive > 0 ? (
                  <div className="p-2 bg-emerald-100 border border-emerald-300 rounded-lg flex items-center justify-between text-emerald-950 font-bold text-xs">
                    <span>Vuelto a entregar:</span>
                    <span className="text-base font-black text-emerald-800">
                      S/ {changeToGive.toFixed(2)}
                    </span>
                  </div>
                ) : isShortPayment ? (
                  <div className="p-2 bg-amber-100 border border-amber-300 rounded-lg flex items-center justify-between text-amber-950 font-bold text-xs">
                    <span>Falta para completar:</span>
                    <span className="text-sm font-black text-amber-900">
                      S/ {shortAmount.toFixed(2)}
                    </span>
                  </div>
                ) : (
                  <div className="p-1.5 bg-slate-100 border border-slate-200 rounded-lg flex items-center justify-between text-slate-600 text-[11px] font-semibold">
                    <span>Pago exacto:</span>
                    <span className="text-slate-800 font-bold">S/ 0.00 de vuelto</span>
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="p-3 bg-white border-t border-slate-200 shrink-0 shadow-xs">
              <button
                id="btn-confirm-sale-submit"
                type="submit"
                disabled={!selectedProduct || selectedProduct.stock < quantity || selectedProduct.stock <= 0}
                className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white font-black rounded-xl shadow-md transition text-sm flex items-center justify-center gap-2 active:scale-[0.99] cursor-pointer"
              >
                <span>CONFIRMAR VENTA (S/ {totalSale.toFixed(2)})</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
