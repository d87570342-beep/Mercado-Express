import React from 'react';
import { 
  LayoutDashboard, 
  ShoppingCart, 
  Package, 
  WalletCards 
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { ActiveTab } from '../types.ts';

export const Navigation: React.FC = () => {
  const { activeTab, setActiveTab, metrics } = useApp();

  const navItems: { id: ActiveTab; label: string; mobileLabel: string; icon: React.ComponentType<{ className?: string }>; badge?: number }[] = [
    { id: 'dashboard', label: 'Inicio', mobileLabel: 'Inicio', icon: LayoutDashboard },
    { id: 'sales', label: 'Ventas', mobileLabel: 'Ventas', icon: ShoppingCart },
    { id: 'products', label: 'Inventario', mobileLabel: 'Inventario', icon: Package, badge: metrics.lowStockCount > 0 ? metrics.lowStockCount : undefined },
    { id: 'cashflow', label: 'Caja y Ganancias', mobileLabel: 'Caja', icon: WalletCards },
  ];

  return (
    <>
      {/* Desktop Horizontal Navigation (under Header) */}
      <nav id="desktop-navigation" className="hidden md:block bg-white border-b border-slate-200 sticky top-[57px] z-20 shadow-xs">
        <div className="max-w-6xl mx-auto px-4 flex items-center justify-between">
          <div className="flex gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-tab-${item.id}`}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-4 py-3.5 text-sm font-semibold border-b-2 transition relative cursor-pointer ${
                    isActive
                      ? 'border-emerald-600 text-emerald-700 bg-emerald-50/50'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-600' : 'text-slate-500'}`} />
                  <span>{item.label}</span>
                  {item.badge !== undefined && (
                    <span className="bg-amber-500 text-slate-950 text-xs px-1.5 py-0.5 rounded-full font-bold">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
          <div className="text-xs text-slate-500 font-medium py-2">
            Hoy: <span className="font-bold text-slate-800">S/ {metrics.todaySalesTotal.toFixed(2)}</span> en ventas
          </div>
        </div>
      </nav>

      {/* Mobile Bottom Sticky Navigation */}
      <nav id="mobile-navigation" className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-30 shadow-[0_-2px_10px_rgba(0,0,0,0.06)]">
        <div className="grid grid-cols-4 h-16 max-w-md mx-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`mobile-nav-${item.id}`}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center justify-center relative py-1 transition cursor-pointer ${
                  isActive ? 'text-emerald-700' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <div className="relative">
                  <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110 stroke-[2.4]' : 'stroke-[1.8]'}`} />
                  {item.badge !== undefined && (
                    <span className="absolute -top-1.5 -right-2.5 bg-amber-500 text-slate-950 text-[10px] w-4 h-4 rounded-full font-black flex items-center justify-center shadow-xs">
                      {item.badge}
                    </span>
                  )}
                </div>
                <span className={`text-[11px] mt-1 font-medium tracking-tight ${isActive ? 'font-bold text-emerald-700' : 'text-slate-500'}`}>
                  {item.mobileLabel}
                </span>
                {isActive && (
                  <span className="absolute top-0 w-8 h-1 bg-emerald-600 rounded-full" />
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
