import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, Sale, UserSession, ActiveTab } from '../types.ts';
import { INITIAL_PRODUCTS, INITIAL_SALES } from '../data/initialData.ts';
import {
  productsService,
  salesService,
  storeService,
} from '../services/firestoreService.ts';
import { testFirestoreConnection } from '../services/firebase.ts';

interface AppContextType {
  user: UserSession;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  products: Product[];
  sales: Sale[];
  isLoading: boolean;
  error: string | null;
  // Owner & Store methods
  updateBodegaInfo: (data: { bodegaName?: string; name?: string }) => Promise<void>;
  login: (usernameOrEmail: string, password: string) => { success: boolean; error?: string };
  register: (name: string, email: string, password: string, bodegaName: string) => { success: boolean; error?: string };
  logout: () => void;
  // Product methods
  addProduct: (data: Omit<Product, 'id' | 'updatedAt'>) => Promise<void>;
  updateProduct: (id: string, data: Partial<Omit<Product, 'id' | 'updatedAt'>>) => Promise<void>;
  clearProductStock: (id: string) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  // Sales methods
  recordSale: (data: { productId: string; quantity: number; amountPaid?: number }) => { success: boolean; error?: string };
  clearSalesHistory: (keepOnlyToday?: boolean) => Promise<void>;
  // Financial metrics
  metrics: {
    totalProductsCount: number;
    lowStockCount: number;
    lowStockProducts: Product[];
    todaySalesCount: number;
    todaySalesTotal: number;
    todayNetProfit: number;
    totalIncome: number;
    netProfit: number;
    grossProfit: number;
    cashBalance: number;
    inventoryCostValue: number;
    inventorySaleValue: number;
  };
  // Quick action modal state
  quickModal: 'sale' | 'product' | null;
  setQuickModal: (modal: 'sale' | 'product' | null) => void;
  // Utility
  resetDemoData: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const DEFAULT_USER: UserSession = {
  id: 'dueno-1',
  name: 'Dueño de la Bodega',
  email: 'dueno@mercadoexpress.pe',
  bodegaName: 'Bodega y Minimarket San Martín',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const todayStr = new Date().toISOString().split('T')[0];

  const [user, setUser] = useState<UserSession>(DEFAULT_USER);
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [quickModal, setQuickModal] = useState<'sale' | 'product' | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // 1. Probar conexión activa con Firestore al iniciar
  useEffect(() => {
    testFirestoreConnection();
  }, []);

  // 2. Suscripciones en tiempo real a Cloud Firestore
  useEffect(() => {
    let productsLoaded = false;
    let salesLoaded = false;

    const checkLoadingState = () => {
      if (productsLoaded && salesLoaded) {
        setIsLoading(false);
      }
    };

    // Suscripción a información del negocio
    const unsubStore = storeService.subscribe(
      (info) => {
        setUser(info);
      },
      (err) => {
        console.error('Error al escuchar store/info:', err);
        setError('Error al sincronizar datos de la bodega.');
      }
    );

    // Suscripción a productos
    const unsubProducts = productsService.subscribe(
      (newProducts) => {
        setProducts(newProducts);
        productsLoaded = true;
        checkLoadingState();
      },
      (err) => {
        console.error('Error al escuchar productos:', err);
        setProducts((prev) => (prev.length === 0 ? INITIAL_PRODUCTS : prev));
        productsLoaded = true;
        checkLoadingState();
      }
    );

    // Suscripción a ventas
    const unsubSales = salesService.subscribe(
      (newSales) => {
        setSales(newSales);
        salesLoaded = true;
        checkLoadingState();
      },
      (err) => {
        console.error('Error al escuchar ventas:', err);
        setSales((prev) => (prev.length === 0 ? INITIAL_SALES : prev));
        salesLoaded = true;
        checkLoadingState();
      }
    );

    return () => {
      unsubStore();
      unsubProducts();
      unsubSales();
    };
  }, []);

  // Guardar datos de la bodega en Firestore
  const updateBodegaInfo = async (data: { bodegaName?: string; name?: string }) => {
    try {
      await storeService.update(data, user.email);
    } catch (err: any) {
      setError('Error al guardar datos de la bodega en Firestore.');
      throw err;
    }
  };

  // Auth local/sesión del dueño
  const login = (usernameOrEmail: string, password: string) => {
    const trimmedUser = usernameOrEmail.trim().toLowerCase();
    const trimmedPass = password.trim();
    if (!trimmedUser || !trimmedPass) {
      return { success: false, error: 'Por favor complete todos los campos.' };
    }
    if (trimmedPass.length < 4) {
      return { success: false, error: 'La contraseña debe tener al menos 4 caracteres.' };
    }
    const newUser: UserSession = {
      id: 'user-' + Date.now(),
      name: trimmedUser.includes('@') ? trimmedUser.split('@')[0] : trimmedUser,
      email: trimmedUser.includes('@') ? trimmedUser : `${trimmedUser}@bodega.com`,
      bodegaName: user.bodegaName || 'Bodega y Minimarket San Martín',
    };
    setUser(newUser);
    return { success: true };
  };

  const register = (name: string, email: string, password: string, bodegaName: string) => {
    if (!name.trim() || !email.trim() || !password.trim()) {
      return { success: false, error: 'Por favor complete todos los campos requeridos.' };
    }
    if (password.length < 4) {
      return { success: false, error: 'La contraseña debe tener al menos 4 caracteres.' };
    }
    const newUser: UserSession = {
      id: 'user-' + Date.now(),
      name: name.trim(),
      email: email.trim().toLowerCase(),
      bodegaName: bodegaName.trim() || 'Mi Bodega Express',
    };
    setUser(newUser);
    updateBodegaInfo({ name: newUser.name, bodegaName: newUser.bodegaName });
    return { success: true };
  };

  const logout = () => {
    setUser(DEFAULT_USER);
  };

  // Operaciones de productos en Firestore
  const addProduct = async (data: Omit<Product, 'id' | 'updatedAt'>) => {
    try {
      await productsService.create(data);
    } catch (err: any) {
      setError('Error al guardar producto en Firestore.');
      throw err;
    }
  };

  const updateProduct = async (id: string, data: Partial<Omit<Product, 'id' | 'updatedAt'>>) => {
    try {
      await productsService.update(id, data);
    } catch (err: any) {
      setError('Error al actualizar producto en Firestore.');
      throw err;
    }
  };

  const clearProductStock = async (id: string) => {
    try {
      await productsService.clearStock(id);
    } catch (err: any) {
      setError('Error al vaciar stock en Firestore.');
      throw err;
    }
  };

  const deleteProduct = async (id: string) => {
    try {
      await productsService.delete(id);
    } catch (err: any) {
      setError('Error al eliminar producto de Firestore.');
      throw err;
    }
  };

  // Registrar venta de forma atómica en Firestore (crear venta + actualizar stock)
  const recordSale = (data: { productId: string; quantity: number; amountPaid?: number }) => {
    const targetProduct = products.find((p) => p.id === data.productId);
    if (!targetProduct) {
      return { success: false, error: 'Producto no encontrado.' };
    }
    if (data.quantity <= 0) {
      return { success: false, error: 'La cantidad debe ser mayor a cero.' };
    }
    if (targetProduct.stock < data.quantity) {
      return {
        success: false,
        error: `Stock insuficiente. Solo quedan ${targetProduct.stock} unidades de ${targetProduct.name}.`,
      };
    }

    const total = targetProduct.salePrice * data.quantity;
    const effectivePaid = (!data.amountPaid || isNaN(data.amountPaid) || data.amountPaid <= 0)
      ? total
      : data.amountPaid;
    const totalCost = targetProduct.purchasePrice * data.quantity;
    const profit = total - totalCost;
    const change = Math.max(0, effectivePaid - total);
    const currentDate = new Date().toISOString().split('T')[0];

    const newSaleData = {
      productId: targetProduct.id,
      productName: targetProduct.name,
      category: targetProduct.category,
      quantity: data.quantity,
      unitPurchasePrice: targetProduct.purchasePrice,
      unitSalePrice: targetProduct.salePrice,
      total,
      profit,
      amountPaid: effectivePaid,
      change,
      date: currentDate,
      timestamp: new Date().toISOString(),
    };

    const remainingStock = targetProduct.stock - data.quantity;

    // Disparar escritura asíncrona a Firestore
    salesService
      .create(newSaleData, targetProduct.id, remainingStock)
      .catch((err) => {
        console.error('Error al guardar venta en Firestore:', err);
        setError('Error al registrar venta en Firestore.');
      });

    return { success: true };
  };

  const clearSalesHistory = async (keepOnlyToday: boolean = true) => {
    try {
      await salesService.clearHistory(keepOnlyToday);
    } catch (err: any) {
      setError('Error al limpiar historial en Firestore.');
      throw err;
    }
  };

  const resetDemoData = async () => {
    try {
      await productsService.seedInitial();
      await salesService.seedInitial();
    } catch (err: any) {
      setError('Error al restablecer datos en Firestore.');
    }
  };

  // Métricas calculadas en vivo desde las ventas y productos de Firestore
  const todaySales = sales.filter((s) => s.date === todayStr);
  const todaySalesTotal = todaySales.reduce((acc, s) => acc + s.total, 0);
  const todayProfitTotal = todaySales.reduce((acc, s) => acc + s.profit, 0);
  const totalIncome = sales.reduce((acc, s) => acc + s.total, 0);
  const grossProfit = sales.reduce((acc, s) => acc + s.profit, 0);
  const netProfit = grossProfit;
  const cashBalance = totalIncome;
  const lowStockProducts = products.filter((p) => p.stock <= p.minStock);
  const inventoryCostValue = products.reduce((acc, p) => acc + p.purchasePrice * p.stock, 0);
  const inventorySaleValue = products.reduce((acc, p) => acc + p.salePrice * p.stock, 0);

  const metrics = {
    totalProductsCount: products.length,
    lowStockCount: lowStockProducts.length,
    lowStockProducts,
    todaySalesCount: todaySales.length,
    todaySalesTotal,
    todayNetProfit: todayProfitTotal,
    totalIncome,
    netProfit,
    grossProfit,
    cashBalance,
    inventoryCostValue,
    inventorySaleValue,
  };

  return (
    <AppContext.Provider
      value={{
        user,
        activeTab,
        setActiveTab,
        products,
        sales,
        isLoading,
        error,
        login,
        register,
        logout,
        updateBodegaInfo,
        addProduct,
        updateProduct,
        clearProductStock,
        deleteProduct,
        recordSale,
        clearSalesHistory,
        metrics,
        quickModal,
        setQuickModal,
        resetDemoData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
