export type BusinessType = 
  | 'bodega'
  | 'minimarket'
  | 'farmacia'
  | 'libreria'
  | 'panaderia'
  | 'restaurante'
  | 'ferreteria'
  | 'otro';

export interface User {
  id: string;
  email: string;
  name: string;
  businessName: string;
  businessType: BusinessType;
  currency: string; // e.g. "S/.", "$", "€", "MX$"
  phone?: string;
  createdAt: string;
}

export interface Product {
  id: string;
  userId: string;
  name: string;
  category: string;
  quantity: number; // Stock actual
  costPrice: number; // Precio de compra
  salePrice: number; // Precio de venta
  minStock: number; // Stock mínimo para alerta
  unit: string; // 'unid', 'kg', 'paq', 'litro'
  createdAt: string;
  updatedAt: string;
}

export interface SaleItem {
  productId: string;
  productName: string;
  quantity: number;
  costPrice: number;
  unitPrice: number;
  subtotal: number;
}

export interface Sale {
  id: string;
  userId: string;
  code: string;
  items: SaleItem[];
  totalAmount: number;
  totalCost: number;
  profit: number;
  paymentMethod: 'efectivo' | 'transferencia' | 'tarjeta' | 'otro';
  amountReceived?: number;
  changeGiven?: number;
  customerNote?: string;
  createdAt: string;
}

export type CashMovementType = 'ingreso' | 'gasto';

export type ExpenseCategory = 
  | 'mercaderia'
  | 'servicios' // Luz, Agua, Internet
  | 'alquiler'
  | 'personal'
  | 'transporte'
  | 'mantenimiento'
  | 'otros';

export interface CashMovement {
  id: string;
  userId: string;
  type: CashMovementType;
  category: string;
  amount: number;
  description: string;
  date: string;
  saleId?: string;
  createdAt: string;
}

export interface DashboardStats {
  todaySalesCount: number;
  todaySalesTotal: number;
  todaySalesProfit: number;
  todayUnitsSold: number;
  totalProductsCount: number;
  lowStockProductsCount: number;
  recentSales: Sale[];
  lowStockProducts: Product[];
}

export interface ReportSummary {
  period: 'today' | 'week' | 'month' | 'all';
  periodLabel: string;
  totalSales: number;
  totalSalesCount: number;
  totalCostOfGoods: number;
  grossProfit: number;
  profitMargin: number;
  totalUnitsSold: number;
  topSellingProducts: {
    productName: string;
    quantitySold: number;
    totalRevenue: number;
    profit: number;
  }[];
  salesByCategory: {
    category: string;
    revenue: number;
    quantitySold: number;
    percentage: number;
  }[];
  timeline: {
    date: string;
    sales: number;
    profit: number;
    count: number;
  }[];
}
