import {
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  getDocs,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase.ts';
import { Product, Sale, UserSession } from '../types.ts';
import { INITIAL_PRODUCTS, INITIAL_SALES } from '../data/initialData.ts';

const DEFAULT_STORE_INFO: UserSession = {
  id: 'dueno-1',
  name: 'Dueño de la Bodega',
  email: 'dueno@mercadoexpress.pe',
  bodegaName: 'Bodega y Minimarket San Martín',
};

// ============================================================
// 1. PRODUCTS SERVICE (CRUD & Real-time Subscriptions)
// ============================================================
export const productsService = {
  subscribe(onData: (products: Product[]) => void, onError?: (error: Error) => void) {
    const path = 'products';
    return onSnapshot(
      collection(db, path),
      async (snapshot) => {
        if (snapshot.empty) {
          try {
            await productsService.seedInitial();
          } catch (err: any) {
            console.error('Error al inicializar productos en Firestore:', err);
          }
          return;
        }

        const items: Product[] = [];
        snapshot.forEach((d) => {
          const data = d.data();
          items.push({
            id: d.id,
            name: data.name,
            category: data.category,
            stock: Number(data.stock) || 0,
            purchasePrice: Number(data.purchasePrice) || 0,
            salePrice: Number(data.salePrice) || 0,
            minStock: Number(data.minStock) || 0,
            updatedAt: data.updatedAt || new Date().toISOString(),
          });
        });
        onData(items);
      },
      (error) => {
        if (onError) onError(error instanceof Error ? error : new Error(String(error)));
        try {
          handleFirestoreError(error, OperationType.LIST, path);
        } catch {
          // Logged to console by handleFirestoreError for diagnostics
        }
      }
    );
  },

  async create(data: Omit<Product, 'id' | 'updatedAt'>): Promise<string> {
    const path = 'products';
    const id = 'prod-' + Date.now();
    const docData: Product = {
      ...data,
      id,
      updatedAt: new Date().toISOString(),
    };
    const targetProject = db.app.options.projectId;
    const fullPath = `${path}/${id}`;
    console.log(`[Firestore] Ejecutando setDoc en proyecto: '${targetProject}', ruta exacta: '${fullPath}'`, docData);

    try {
      await setDoc(doc(db, path, id), {
        name: docData.name,
        category: docData.category,
        stock: docData.stock,
        purchasePrice: docData.purchasePrice,
        salePrice: docData.salePrice,
        minStock: docData.minStock,
        updatedAt: docData.updatedAt,
      });
      console.log(`[Firestore] ESCRITURA CONFIRMADA EXITOSAMENTE: Proyecto '${targetProject}', documento '${fullPath}'`);
      return id;
    } catch (err: any) {
      console.error(`[Firestore ERROR] Error al ejecutar setDoc en '${fullPath}':`, {
        code: err?.code || 'SIN_CODIGO',
        message: err?.message || String(err),
        projectId: targetProject,
        path: fullPath,
      });
      throw err;
    }
  },

  async update(id: string, updates: Partial<Omit<Product, 'id' | 'updatedAt'>>): Promise<void> {
    const path = `products/${id}`;
    try {
      await updateDoc(doc(db, 'products', id), {
        ...updates,
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  },

  async clearStock(id: string): Promise<void> {
    const path = `products/${id}`;
    try {
      await updateDoc(doc(db, 'products', id), {
        stock: 0,
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  },

  async delete(id: string): Promise<void> {
    const path = `products/${id}`;
    try {
      await deleteDoc(doc(db, 'products', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  },

  async seedInitial(): Promise<void> {
    const path = 'products';
    const batch = writeBatch(db);
    INITIAL_PRODUCTS.forEach((prod) => {
      const docRef = doc(db, path, prod.id);
      batch.set(docRef, {
        name: prod.name,
        category: prod.category,
        stock: prod.stock,
        purchasePrice: prod.purchasePrice,
        salePrice: prod.salePrice,
        minStock: prod.minStock,
        updatedAt: prod.updatedAt,
      });
    });
    try {
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  },
};

// ============================================================
// 2. SALES SERVICE (CRUD & Real-time Subscriptions)
// ============================================================
export const salesService = {
  subscribe(onData: (sales: Sale[]) => void, onError?: (error: Error) => void) {
    const path = 'sales';
    return onSnapshot(
      collection(db, path),
      async (snapshot) => {
        if (snapshot.empty) {
          try {
            await salesService.seedInitial();
          } catch (err: any) {
            console.error('Error al inicializar ventas en Firestore:', err);
          }
          return;
        }

        const items: Sale[] = [];
        snapshot.forEach((d) => {
          const data = d.data();
          items.push({
            id: d.id,
            productId: data.productId,
            productName: data.productName,
            category: data.category,
            quantity: Number(data.quantity) || 1,
            unitPurchasePrice: Number(data.unitPurchasePrice) || 0,
            unitSalePrice: Number(data.unitSalePrice) || 0,
            total: Number(data.total) || 0,
            profit: Number(data.profit) || 0,
            amountPaid: Number(data.amountPaid) || Number(data.total) || 0,
            change: Number(data.change) || 0,
            date: data.date,
            timestamp: data.timestamp,
          });
        });
        items.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
        onData(items);
      },
      (error) => {
        if (onError) onError(error instanceof Error ? error : new Error(String(error)));
        try {
          handleFirestoreError(error, OperationType.LIST, path);
        } catch {
          // Logged to console by handleFirestoreError for diagnostics
        }
      }
    );
  },

  async create(
    saleData: Omit<Sale, 'id'>,
    deductProductId?: string,
    deductStockRemaining?: number
  ): Promise<string> {
    const path = 'sales';
    const saleId = 'sale-' + Date.now();
    try {
      const batch = writeBatch(db);
      const saleRef = doc(db, path, saleId);
      batch.set(saleRef, saleData);

      if (deductProductId && deductStockRemaining !== undefined) {
        const prodRef = doc(db, 'products', deductProductId);
        batch.update(prodRef, {
          stock: deductStockRemaining,
          updatedAt: new Date().toISOString(),
        });
      }

      await batch.commit();
      return saleId;
    } catch (err) {
      return handleFirestoreError(err, OperationType.CREATE, path);
    }
  },

  async clearHistory(keepOnlyToday: boolean = true): Promise<void> {
    const path = 'sales';
    const todayStr = new Date().toISOString().split('T')[0];
    try {
      const snapshot = await getDocs(collection(db, path));
      const batch = writeBatch(db);
      snapshot.docs.forEach((d) => {
        const data = d.data();
        if (!keepOnlyToday || data.date !== todayStr) {
          batch.delete(d.ref);
        }
      });
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  },

  async seedInitial(): Promise<void> {
    const path = 'sales';
    const batch = writeBatch(db);
    INITIAL_SALES.forEach((s) => {
      const docRef = doc(db, path, s.id);
      batch.set(docRef, {
        productId: s.productId,
        productName: s.productName,
        category: s.category,
        quantity: s.quantity,
        unitPurchasePrice: s.unitPurchasePrice,
        unitSalePrice: s.unitSalePrice,
        total: s.total,
        profit: s.profit,
        amountPaid: s.amountPaid || s.total,
        change: s.change || 0,
        date: s.date,
        timestamp: s.timestamp,
      });
    });
    try {
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  },
};

// ============================================================
// 3. STORE INFO SERVICE (/store/info)
// ============================================================
export const storeService = {
  subscribe(onData: (info: UserSession) => void, onError?: (error: Error) => void) {
    const path = 'store/info';
    return onSnapshot(
      doc(db, 'store', 'info'),
      (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data();
          onData({
            id: 'dueno-1',
            name: data.name || DEFAULT_STORE_INFO.name,
            email: data.email || DEFAULT_STORE_INFO.email,
            bodegaName: data.bodegaName || DEFAULT_STORE_INFO.bodegaName,
          });
        } else {
          setDoc(doc(db, 'store', 'info'), {
            name: DEFAULT_STORE_INFO.name,
            email: DEFAULT_STORE_INFO.email,
            bodegaName: DEFAULT_STORE_INFO.bodegaName,
          }).catch((err) => handleFirestoreError(err, OperationType.CREATE, path));
        }
      },
      (error) => {
        if (onError) onError(error instanceof Error ? error : new Error(String(error)));
        try {
          handleFirestoreError(error, OperationType.GET, path);
        } catch {
          // Logged to console by handleFirestoreError for diagnostics
        }
      }
    );
  },

  async update(data: Partial<Pick<UserSession, 'name' | 'bodegaName'>>, currentEmail: string): Promise<void> {
    const path = 'store/info';
    try {
      await setDoc(
        doc(db, 'store', 'info'),
        {
          name: data.name || DEFAULT_STORE_INFO.name,
          bodegaName: data.bodegaName || DEFAULT_STORE_INFO.bodegaName,
          email: currentEmail || DEFAULT_STORE_INFO.email,
        },
        { merge: true }
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  },
};
