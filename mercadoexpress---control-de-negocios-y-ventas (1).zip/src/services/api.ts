import {
  User,
  Product,
  Sale,
  CashMovement,
  DashboardStats,
  ReportSummary,
  BusinessType
} from '../types/index.ts';

const TOKEN_KEY = 'mercado_express_token';

export function getStoredToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setStoredToken(token: string): void {
  try {
    localStorage.setItem(TOKEN_KEY, token);
  } catch (err) {
    console.error('Failed to save token to localStorage', err);
  }
}

export function clearStoredToken(): void {
  try {
    localStorage.removeItem(TOKEN_KEY);
  } catch (err) {
    console.error('Failed to remove token from localStorage', err);
  }
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(endpoint, {
    ...options,
    headers
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || `Error en la solicitud (${res.status})`);
  }

  return data as T;
}

export const api = {
  auth: {
    login: async (email: string, password: string) => {
      const data = await request<{ user: User; token: string }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });
      setStoredToken(data.token);
      return data;
    },

    register: async (userData: {
      email: string;
      password: string;
      name: string;
      businessName: string;
      businessType: BusinessType;
      currency?: string;
      phone?: string;
    }) => {
      const data = await request<{ user: User; token: string }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(userData)
      });
      setStoredToken(data.token);
      return data;
    },

    getOwnerSession: async () => {
      const data = await request<{ user: User; token: string }>('/api/auth/owner-session', {
        method: 'POST'
      });
      setStoredToken(data.token);
      return data;
    },

    demo: async () => {
      const data = await request<{ user: User; token: string }>('/api/auth/demo', {
        method: 'POST'
      });
      setStoredToken(data.token);
      return data;
    },

    resetDemo: async () => {
      return request<{ message: string }>('/api/auth/demo/reset', {
        method: 'POST'
      });
    },

    me: async () => {
      return request<{ user: User }>('/api/auth/me');
    },

    updateProfile: async (updates: Partial<Pick<User, 'businessName' | 'name' | 'currency' | 'phone' | 'businessType'>>) => {
      return request<{ user: User }>('/api/auth/profile', {
        method: 'PUT',
        body: JSON.stringify(updates)
      });
    },

    logout: () => {
      clearStoredToken();
    }
  },

  products: {
    list: async (filters?: { search?: string; category?: string; lowStockOnly?: boolean }) => {
      const params = new URLSearchParams();
      if (filters?.search) params.append('search', filters.search);
      if (filters?.category) params.append('category', filters.category);
      if (filters?.lowStockOnly) params.append('lowStockOnly', 'true');
      const query = params.toString() ? `?${params.toString()}` : '';
      return request<{ products: Product[] }>(`/api/products${query}`);
    },

    create: async (productData: Omit<Product, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => {
      return request<{ product: Product }>('/api/products', {
        method: 'POST',
        body: JSON.stringify(productData)
      });
    },

    update: async (id: string, updates: Partial<Product>) => {
      return request<{ product: Product }>(`/api/products/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updates)
      });
    },

    delete: async (id: string) => {
      return request<{ message: string }>(`/api/products/${id}`, {
        method: 'DELETE'
      });
    }
  },

  sales: {
    list: async (filters?: { period?: string; limit?: number }) => {
      const params = new URLSearchParams();
      if (filters?.period) params.append('period', filters.period);
      if (filters?.limit) params.append('limit', String(filters.limit));
      const query = params.toString() ? `?${params.toString()}` : '';
      return request<{ sales: Sale[] }>(`/api/sales${query}`);
    },

    get: async (id: string) => {
      return request<{ sale: Sale }>(`/api/sales/${id}`);
    },

    create: async (saleData: {
      items: { productId: string; quantity: number }[];
      paymentMethod: 'efectivo' | 'transferencia' | 'tarjeta' | 'otro';
      amountReceived?: number;
      customerNote?: string;
    }) => {
      return request<{ sale: Sale; updatedProducts: Product[] }>('/api/sales', {
        method: 'POST',
        body: JSON.stringify(saleData)
      });
    }
  },

  cash: {
    list: async (filters?: { period?: string; type?: 'ingreso' | 'gasto' }) => {
      const params = new URLSearchParams();
      if (filters?.period) params.append('period', filters.period);
      if (filters?.type) params.append('type', filters.type);
      const query = params.toString() ? `?${params.toString()}` : '';
      return request<{ movements: CashMovement[] }>(`/api/cash${query}`);
    },

    create: async (data: {
      type: 'ingreso' | 'gasto';
      category: string;
      amount: number;
      description: string;
      date?: string;
    }) => {
      return request<{ movement: CashMovement }>('/api/cash', {
        method: 'POST',
        body: JSON.stringify(data)
      });
    },

    delete: async (id: string) => {
      return request<{ message: string }>(`/api/cash/${id}`, {
        method: 'DELETE'
      });
    }
  },

  dashboard: {
    getStats: async () => {
      return request<{ stats: DashboardStats }>('/api/dashboard/stats');
    }
  },

  reports: {
    get: async (period: 'today' | 'week' | 'month' | 'all') => {
      return request<{ report: ReportSummary }>(`/api/reports?period=${period}`);
    }
  }
};
