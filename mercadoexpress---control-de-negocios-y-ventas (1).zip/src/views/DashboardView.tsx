import React from 'react';
import { 
  Plus, 
  ShoppingCart, 
  Package, 
  AlertTriangle, 
  ArrowUpRight, 
  Clock, 
  DollarSign,
  TrendingUp,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';

export const DashboardView: React.FC = () => {
  const { 
    user, 
    metrics, 
    sales, 
    setActiveTab, 
    setQuickModal 
  } = useApp();

  const todayStr = new Date().toISOString().split('T')[0];
  const todaySales = sales.filter((s) => s.date === todayStr);
  const todayProfit = todaySales.reduce((acc, s) => acc + s.profit, 0);

  // Recent sales activities
  const recentActivities = todaySales.slice(0, 6).map((s) => ({
    id: s.id,
    title: s.productName,
    subtitle: `${s.quantity} und. vendidas`,
    amount: s.total,
    profit: s.profit,
    time: s.timestamp ? new Date(s.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Hoy',
  }));

  return (
    <div id="dashboard-view" className="space-y-6 pb-20 md:pb-8">
      {/* Saludo y Nombre del Negocio */}
      <div className="bg-slate-900 text-white rounded-2xl p-5 sm:p-6 border border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-emerald-400 text-xs font-bold uppercase tracking-wider">
            Ventana Inicio
          </span>
          <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
            {user.bodegaName || 'Mi Negocio'}
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Bienvenido, <strong className="text-white">{user.name || 'Dueño'}</strong> &bull; Panel de control simplificado
          </p>
        </div>

        {/* 2 BOTONES PRINCIPALES: Vender y Agregar Producto */}
        <div className="flex items-center gap-2.5 sm:gap-3 flex-wrap">
          <button
            id="quick-action-sale"
            onClick={() => setQuickModal('sale')}
            className="flex items-center gap-2 px-5 py-3 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white rounded-xl shadow-md transition font-bold text-sm cursor-pointer"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>Vender / Cobrar</span>
          </button>

          <button
            id="quick-action-product"
            onClick={() => setQuickModal('product')}
            className="flex items-center gap-2 px-4 py-3 bg-slate-800 hover:bg-slate-700 active:bg-slate-950 text-white rounded-xl border border-slate-700 transition font-bold text-xs sm:text-sm cursor-pointer"
          >
            <Plus className="w-4 h-4 text-emerald-400" />
            <span>+ Agregar Producto</span>
          </button>
        </div>
      </div>

      {/* EXACTAMENTE LAS 2 MÉTRICAS SOLICITADAS: VENTAS DE HOY y GANANCIA */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Card 1: Ventas de Hoy */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">
              Ventas de Hoy
            </span>
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <ShoppingCart className="w-5 h-5" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              S/ {metrics.todaySalesTotal.toFixed(2)}
            </div>
            <div className="text-xs text-emerald-700 font-semibold mt-1 flex items-center gap-1.5">
              <span className="bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-md font-bold text-[11px]">
                {todaySales.length} {todaySales.length === 1 ? 'venta realizada' : 'ventas realizadas'}
              </span>
              <span>hoy</span>
            </div>
          </div>
        </div>

        {/* Card 2: Ganancia */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
              Ganancia de Hoy
            </span>
            <div className="w-9 h-9 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black text-teal-700 tracking-tight">
              + S/ {todayProfit.toFixed(2)}
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Ganancia neta calculada en tiempo real
            </div>
          </div>
        </div>
      </div>

      {/* SECCIÓN: STOCKS BAJOS & HISTORIAL DE VENTAS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Columna 1: Stocks Bajos */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3.5">
              <div className="flex items-center gap-2">
                <AlertTriangle className={`w-5 h-5 ${metrics.lowStockCount > 0 ? 'text-amber-500' : 'text-slate-400'}`} />
                <h4 className="font-extrabold text-slate-900 text-sm sm:text-base">
                  Stocks Bajos
                </h4>
              </div>
              <button
                onClick={() => setActiveTab('products')}
                className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
              >
                <span>Ver inventario</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {metrics.lowStockProducts.length === 0 ? (
              <div className="p-6 bg-emerald-50 text-emerald-800 rounded-xl text-xs font-semibold text-center flex flex-col items-center justify-center gap-1.5">
                <CheckCircle2 className="w-7 h-7 text-emerald-600 mb-0.5" />
                <p className="font-bold text-slate-900">¡Todo el stock está al día!</p>
                <p className="text-slate-500 text-[11px]">No hay productos por debajo del stock mínimo.</p>
              </div>
            ) : (
              <div className="space-y-2">
                <p className="text-xs text-amber-900 bg-amber-50 p-2 rounded-xl border border-amber-200 font-medium">
                  {metrics.lowStockCount} {metrics.lowStockCount === 1 ? 'producto necesita reposición:' : 'productos necesitan reposición:'}
                </p>
                {metrics.lowStockProducts.slice(0, 4).map((prod) => (
                  <div key={prod.id} className="p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl flex items-center justify-between text-xs transition">
                    <div>
                      <span className="font-bold text-slate-900 block">{prod.name}</span>
                      <span className="text-[11px] text-slate-500">Mínimo: {prod.minStock} und.</span>
                    </div>
                    <span className="bg-amber-500 text-slate-950 font-black px-2.5 py-1 rounded-lg text-xs">
                      Quedan: {prod.stock}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Columna 2: Historial de Ventas */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3.5">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-emerald-600" />
                <h4 className="font-extrabold text-slate-900 text-sm sm:text-base">
                  Historial de Ventas
                </h4>
              </div>
              <button
                onClick={() => setActiveTab('sales')}
                className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
              >
                <span>Ver todo</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {recentActivities.length === 0 ? (
              <div className="p-6 bg-slate-50 text-slate-500 rounded-xl text-xs text-center flex flex-col items-center justify-center gap-1.5">
                <ShoppingCart className="w-7 h-7 text-slate-300 mb-0.5" />
                <p className="font-bold text-slate-700">Aún no hay ventas hoy</p>
                <p className="text-slate-400 text-[11px]">Usa el botón "Vender" para registrar cobros.</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {recentActivities.map((act) => (
                  <div key={act.id} className="py-2.5 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-lg flex items-center justify-center font-bold bg-emerald-100 text-emerald-800 shrink-0">
                        <ArrowUpRight className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-bold text-slate-900 truncate max-w-[150px] sm:max-w-xs">
                          {act.title}
                        </div>
                        <div className="text-[10px] text-slate-400">{act.subtitle}</div>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-black text-slate-900">
                        S/ {act.amount.toFixed(2)}
                      </div>
                      <div className="text-[10px] font-bold text-emerald-700">
                        +{act.profit.toFixed(2)} ganancia
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
