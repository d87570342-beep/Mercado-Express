import React, { useState, useMemo } from 'react';
import { 
  Package, 
  Plus, 
  Search, 
  AlertTriangle, 
  Edit, 
  Trash2, 
  Ban,
  CheckCircle2,
  X
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { Product, ProductCategory } from '../types.ts';
import { ProductModal } from '../components/ProductModal.tsx';

const CATEGORIES: ('Todas' | ProductCategory)[] = [
  'Todas',
  'Abarrotes',
  'Bebidas y Licores',
  'Lácteos y Huevos',
  'Limpieza y Aseo',
  'Snacks y Golosinas',
  'Frutas y Verduras',
  'Panadería y Embutidos',
  'Cuidado Personal',
  'Otros',
];

export const ProductsView: React.FC = () => {
  const { products, deleteProduct, clearProductStock, metrics } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'Todas' | ProductCategory>('Todas');
  const [filterLowStockOnly, setFilterLowStockOnly] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  // Modal state
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [productToEdit, setProductToEdit] = useState<Product | null>(null);
  const [actionProduct, setActionProduct] = useState<Product | null>(null);

  const showNotification = (msg: string) => {
    setFeedbackMessage(msg);
    setTimeout(() => {
      setFeedbackMessage(null);
    }, 3000);
  };

  // Filtered list
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesSearch =
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.category.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory =
        selectedCategory === 'Todas' || p.category === selectedCategory;
      const matchesLowStock = filterLowStockOnly ? p.stock <= p.minStock : true;
      return matchesSearch && matchesCategory && matchesLowStock;
    });
  }, [products, searchTerm, selectedCategory, filterLowStockOnly]);

  const handleOpenAdd = () => {
    setProductToEdit(null);
    setIsProductModalOpen(true);
  };

  const handleOpenEdit = (p: Product) => {
    setProductToEdit(p);
    setIsProductModalOpen(true);
  };

  const handleClearStockConfirmed = () => {
    if (!actionProduct) return;
    clearProductStock(actionProduct.id);
    showNotification(`Stock de "${actionProduct.name}" puesto en 0 unidades.`);
    setActionProduct(null);
  };

  const handleDeleteProductConfirmed = () => {
    if (!actionProduct) return;
    deleteProduct(actionProduct.id);
    showNotification(`Producto "${actionProduct.name}" eliminado del catálogo.`);
    setActionProduct(null);
  };

  return (
    <div id="products-view" className="space-y-6 pb-20 md:pb-8">
      {/* Toast Feedback */}
      {feedbackMessage && (
        <div className="fixed top-18 right-4 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 text-xs font-bold animate-in fade-in slide-in-from-top-3">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{feedbackMessage}</span>
        </div>
      )}

      {/* Top Header & Add button */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl sm:text-2xl font-black text-slate-900">
              Inventario de Productos
            </h2>
            <span className="bg-slate-100 text-slate-700 text-xs px-2.5 py-1 rounded-full font-bold">
              {products.length} productos
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Administración de productos: agrega nuevos productos, edita precios o vacía el stock.
          </p>
        </div>

        <button
          id="btn-add-product"
          onClick={handleOpenAdd}
          className="py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2 text-sm self-stretch sm:self-auto active:scale-[0.98] cursor-pointer"
        >
          <Plus className="w-5 h-5" />
          <span>Nuevo Producto</span>
        </button>
      </div>

      {/* Estado rápido de inventario */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center shrink-0">
            <Package className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-bold block">Total de Productos Registrados</span>
            <span className="text-xl font-black text-slate-900">
              {products.length} productos
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-5 h-5 text-amber-700" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-bold block">Productos con Poco Stock</span>
            <span className="text-xl font-black text-amber-700">
              {metrics.lowStockCount} por reponer
            </span>
          </div>
        </div>
      </div>

      {/* Search and Category Filters */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search bar */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
            <input
              id="search-product-input"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar producto por nombre o categoría..."
              className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium text-slate-800"
            />
          </div>

          {/* Low stock toggle */}
          <button
            id="toggle-low-stock-filter"
            onClick={() => setFilterLowStockOnly(!filterLowStockOnly)}
            className={`px-4 py-2 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-1.5 cursor-pointer ${
              filterLowStockOnly
                ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Solo poco stock ({metrics.lowStockCount})</span>
          </button>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-1 scrollbar-none text-xs">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl font-semibold whitespace-nowrap transition cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Products Table (Desktop) & Cards (Mobile) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {filteredProducts.length === 0 ? (
          <div className="text-center py-12 px-4">
            <Package className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h4 className="text-base font-bold text-slate-800">No se encontraron productos</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Prueba cambiando el término de búsqueda o registra un nuevo producto.
            </p>
            <button
              onClick={handleOpenAdd}
              className="mt-4 px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 transition inline-flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Agregar producto</span>
            </button>
          </div>
        ) : (
          <>
            {/* Desktop Table View */}
            <div className="hidden lg:block overflow-x-auto">
              <table id="products-table" className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-black uppercase tracking-wider text-slate-500">
                    <th className="py-3.5 px-4">Producto</th>
                    <th className="py-3.5 px-4">Categoría</th>
                    <th className="py-3.5 px-4 text-center">Stock</th>
                    <th className="py-3.5 px-4 text-right">P. Compra</th>
                    <th className="py-3.5 px-4 text-right">P. Venta</th>
                    <th className="py-3.5 px-4 text-right">Ganancia</th>
                    <th className="py-3.5 px-4 text-center">Opciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {filteredProducts.map((p) => {
                    const isZeroStock = p.stock === 0;
                    const isLowStock = !isZeroStock && p.stock <= p.minStock;
                    const unitProfit = p.salePrice - p.purchasePrice;

                    return (
                      <tr key={p.id} className="hover:bg-slate-50/80 transition">
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-slate-900">{p.name}</div>
                          {isZeroStock && (
                            <span className="inline-flex items-center gap-1 text-[10px] font-black text-rose-800 bg-rose-100 px-2 py-0.5 rounded-md mt-0.5">
                              <Ban className="w-3 h-3" />
                              Sin stock (0 unidades)
                            </span>
                          )}
                          {isLowStock && (
                            <span className="inline-flex items-center gap-1 text-[10px] font-black text-amber-900 bg-amber-100 px-2 py-0.5 rounded-md mt-0.5">
                              <AlertTriangle className="w-3 h-3" />
                              Poco stock (≤ {p.minStock})
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="bg-slate-100 text-slate-700 px-2.5 py-1 rounded-md text-xs font-medium">
                            {p.category}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          <span
                            className={`font-black px-2.5 py-1 rounded-lg text-xs inline-block ${
                              isZeroStock
                                ? 'bg-rose-100 text-rose-800'
                                : isLowStock
                                ? 'bg-amber-100 text-amber-950 font-black'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {p.stock} und.
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right font-medium text-slate-600">
                          S/ {p.purchasePrice.toFixed(2)}
                        </td>
                        <td className="py-3.5 px-4 text-right font-extrabold text-slate-900">
                          S/ {p.salePrice.toFixed(2)}
                        </td>
                        <td className="py-3.5 px-4 text-right font-bold text-emerald-700">
                          + S/ {unitProfit.toFixed(2)}
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="flex items-center justify-center gap-1.5">
                            {/* Botón Editar */}
                            <button
                              id={`btn-edit-prod-${p.id}`}
                              onClick={() => handleOpenEdit(p)}
                              className="py-1.5 px-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                              title="Editar datos del producto"
                            >
                              <Edit className="w-3.5 h-3.5 text-slate-600" />
                              <span>Editar</span>
                            </button>
                            {/* Botón Papelera: Quitar stock o eliminar */}
                            <button
                              id={`btn-trash-prod-${p.id}`}
                              onClick={() => setActionProduct(p)}
                              className="p-1.5 text-rose-600 hover:text-white hover:bg-rose-600 bg-rose-50 hover:border-rose-600 border border-rose-200 rounded-lg transition flex items-center justify-center cursor-pointer shadow-2xs"
                              title="Quitar stock o eliminar producto"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile Card List View */}
            <div className="lg:hidden divide-y divide-slate-200">
              {filteredProducts.map((p) => {
                const isZeroStock = p.stock === 0;
                const isLowStock = !isZeroStock && p.stock <= p.minStock;
                const unitProfit = p.salePrice - p.purchasePrice;

                return (
                  <div key={p.id} className="p-4 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                          {p.category}
                        </span>
                        <h4 className="font-extrabold text-sm text-slate-900 leading-tight">
                          {p.name}
                        </h4>
                      </div>
                      <span
                        className={`font-black text-xs px-2.5 py-1 rounded-lg shrink-0 ${
                          isZeroStock
                            ? 'bg-rose-100 text-rose-800'
                            : isLowStock
                            ? 'bg-amber-100 text-amber-950'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {p.stock} und.
                      </span>
                    </div>

                    {isZeroStock && (
                      <div className="bg-rose-50 text-rose-900 border border-rose-200 rounded-lg px-2.5 py-1 text-[11px] font-bold flex items-center gap-1.5">
                        <Ban className="w-3.5 h-3.5 shrink-0" />
                        <span>Sin stock (0 unidades disponibles)</span>
                      </div>
                    )}

                    {isLowStock && (
                      <div className="bg-amber-50 text-amber-900 border border-amber-200 rounded-lg px-2.5 py-1 text-[11px] font-bold flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        <span>¡Poco stock! Quedan {p.stock} unidades</span>
                      </div>
                    )}

                    <div className="grid grid-cols-3 gap-2 bg-slate-50 p-2.5 rounded-xl text-center text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">Compra</span>
                        <span className="font-bold text-slate-700">S/ {p.purchasePrice.toFixed(2)}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">Venta</span>
                        <span className="font-extrabold text-slate-900">S/ {p.salePrice.toFixed(2)}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">Ganancia</span>
                        <span className="font-bold text-emerald-700">+ S/ {unitProfit.toFixed(2)}</span>
                      </div>
                    </div>

                    {/* Action Buttons: Editar y Papelera */}
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        id={`mob-edit-prod-${p.id}`}
                        onClick={() => handleOpenEdit(p)}
                        className="flex-1 py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
                      >
                        <Edit className="w-3.5 h-3.5" />
                        <span>Editar</span>
                      </button>
                      <button
                        id={`mob-trash-prod-${p.id}`}
                        onClick={() => setActionProduct(p)}
                        className="flex-1 py-2 px-3 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                        <span>Quitar o Eliminar</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>

      {/* Product Add/Edit Modal */}
      <ProductModal
        isOpen={isProductModalOpen}
        productToEdit={productToEdit}
        onClose={() => setIsProductModalOpen(false)}
      />

      {/* Papelera Modal: Quitar stock o Eliminar producto */}
      {actionProduct && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between gap-3 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900 leading-tight">
                    ¿Qué deseas hacer?
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Producto: <span className="font-bold text-slate-800">{actionProduct.name}</span>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActionProduct(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Info card */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 mb-4 flex items-center justify-between text-xs">
              <div>
                <span className="text-slate-400 block text-[10px] font-bold uppercase">Categoría</span>
                <span className="font-semibold text-slate-800">{actionProduct.category}</span>
              </div>
              <div className="text-right">
                <span className="text-slate-400 block text-[10px] font-bold uppercase">Stock Actual</span>
                <span className={`font-black ${actionProduct.stock === 0 ? 'text-rose-600' : 'text-emerald-700'}`}>
                  {actionProduct.stock} unidades
                </span>
              </div>
            </div>

            <div className="space-y-2.5">
              {/* Opción 1: Quitar el stock (Poner en 0) */}
              <button
                id="btn-confirm-clear-stock"
                onClick={handleClearStockConfirmed}
                disabled={actionProduct.stock === 0}
                className={`w-full p-3.5 rounded-xl border text-left flex items-center gap-3 transition cursor-pointer ${
                  actionProduct.stock === 0
                    ? 'bg-slate-50 border-slate-200 opacity-60 cursor-not-allowed text-slate-400'
                    : 'bg-amber-50/80 hover:bg-amber-100 border-amber-200 text-amber-950 active:scale-[0.99]'
                }`}
              >
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                  actionProduct.stock === 0 ? 'bg-slate-200 text-slate-400' : 'bg-amber-200 text-amber-800'
                }`}>
                  <Ban className="w-4 h-4" />
                </div>
                <div className="flex-1">
                  <div className="text-xs font-black text-slate-900">
                    Quitar el stock (Poner en 0 unidades)
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    {actionProduct.stock === 0
                      ? 'El producto ya está en 0 unidades disponibles.'
                      : 'Mantiene el producto en el catálogo pero pone su stock en 0.'}
                  </div>
                </div>
              </button>

              {/* Opción 2: Eliminar producto por completo */}
              <button
                id="btn-confirm-delete-product"
                onClick={handleDeleteProductConfirmed}
                className="w-full p-3.5 bg-rose-50/80 hover:bg-rose-100 border border-rose-200 rounded-xl text-left flex items-center gap-3 transition text-rose-950 active:scale-[0.99] cursor-pointer"
              >
                <div className="w-9 h-9 rounded-lg bg-rose-200 text-rose-700 flex items-center justify-center shrink-0">
                  <Trash2 className="w-4 h-4" />
                </div>
                <div className="flex-1">
                  <div className="text-xs font-black text-rose-800">
                    Eliminar producto por completo
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Borra definitivamente el producto de tu catálogo de inventario.
                  </div>
                </div>
              </button>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setActionProduct(null)}
                className="py-2 px-4 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition cursor-pointer"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
