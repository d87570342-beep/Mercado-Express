import React, { useState, useMemo } from 'react';
import { 
  WalletCards, 
  ArrowUpRight, 
  Calendar, 
  DollarSign,
  TrendingUp,
  ShoppingCart
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';

export const CashFlowView: React.FC = () => {
  const { sales, metrics } = useApp();
  const [activeTab, setActiveTab] = useState<'movimientos' | 'diario'>('movimientos');

  // Sales movements
  const allMovements = useMemo(() => {
    return sales.map((s) => ({
      id: s.id,
      concept: `${s.quantity}x ${s.productName}`,
      category: s.category,
      amount: s.total,
      profit: s.profit,
      date: s.date,
      timestamp: s.timestamp,
    })).sort((a, b) => (b.timestamp || b.date).localeCompare(a.timestamp || a.date));
  }, [sales]);

  // Daily Summary by Date
  const dailySummary = useMemo(() => {
    const map = new Map<string, { date: string; income: number; profit: number; count: number }>();
    sales.forEach((s) => {
      const entry = map.get(s.date) || { date: s.date, income: 0, profit: 0, count: 0 };
      entry.income += s.total;
      entry.profit += s.profit;
      entry.count += 1;
      map.set(s.date, entry);
    });
    return Array.from(map.values()).sort((a, b) => b.date.localeCompare(a.date));
  }, [sales]);

  return (
    <div id="cashflow-view" className="space-y-6 pb-20 md:pb-8">
      {/* Encabezado */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 flex items-center gap-2">
            <WalletCards className="w-6 h-6 text-emerald-600" />
            Caja y Ganancias
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Control de ingresos de dinero en caja y cálculo de ganancias de tus ventas.
          </p>
        </div>

        {/* Toggle de vista */}
        <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-bold self-start sm:self-auto">
          <button
            onClick={() => setActiveTab('movimientos')}
            className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
              activeTab === 'movimientos' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Historial de Ventas ({sales.length})
          </button>
          <button
            onClick={() => setActiveTab('diario')}
            className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
              activeTab === 'diario' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Resumen por Día
          </button>
        </div>
      </div>

      {/* 3 TARJETAS PRINCIPALES DE CAJA */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Total Ingresado en Caja */}
        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Total Cobrado en Caja
            </span>
            <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-700">
            S/ {metrics.totalIncome.toFixed(2)}
          </div>
          <span className="text-[10px] text-slate-400 mt-0.5 block font-medium">
            Dinero total recaudado en ventas
          </span>
        </div>

        {/* Ganancia Neta Total */}
        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Ganancia Total
            </span>
            <div className="w-7 h-7 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-teal-700">
            + S/ {metrics.grossProfit.toFixed(2)}
          </div>
          <span className="text-[10px] text-slate-400 mt-0.5 block font-medium">
            Margen de ganancia acumulado
          </span>
        </div>

        {/* Total Transacciones */}
        <div className="bg-slate-900 text-white p-4.5 rounded-2xl shadow-xs">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
              Ventas Registradas
            </span>
            <div className="w-7 h-7 rounded-lg bg-white/10 text-emerald-400 flex items-center justify-center font-bold">
              <ShoppingCart className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-400">
            {sales.length}
          </div>
          <span className="text-[10px] text-slate-400 mt-0.5 block font-medium">
            Operaciones completadas
          </span>
        </div>
      </div>

      {/* VISTA 1: HISTORIAL DE VENTAS EN CAJA */}
      {activeTab === 'movimientos' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              Movimientos de Ventas en Caja
            </h3>
            <span className="text-xs text-slate-400 font-semibold">
              {allMovements.length} {allMovements.length === 1 ? 'registro' : 'registros'}
            </span>
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {allMovements.length === 0 ? (
              <div className="py-12 text-center text-xs text-slate-400">
                Aún no hay ventas registradas.
              </div>
            ) : (
              allMovements.map((mov) => (
                <div
                  key={mov.id}
                  className="p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200 transition flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center font-bold shrink-0 bg-emerald-100 text-emerald-700">
                      <ShoppingCart className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-bold text-slate-900 text-sm">{mov.concept}</div>
                      <div className="text-[10px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                        <span className="font-medium text-slate-600">{mov.category}</span>
                        <span>&bull;</span>
                        <span>{mov.date}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-black text-sm text-emerald-700">
                      + S/ {mov.amount.toFixed(2)}
                    </div>
                    <span className="text-[10px] font-bold text-teal-700 block">
                      Ganancia: + S/ {mov.profit.toFixed(2)}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* VISTA 2: RESUMEN POR DÍA */}
      {activeTab === 'diario' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 space-y-3">
          <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-emerald-600" />
            Ventas y Ganancias por Día
          </h3>
          <div className="divide-y divide-slate-100">
            {dailySummary.length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-400">
                Aún no hay movimientos registrados.
              </div>
            ) : (
              dailySummary.map((item) => (
                <div key={item.date} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                  <div>
                    <span className="font-extrabold text-slate-900 text-sm">{item.date}</span>
                    <span className="text-[11px] text-slate-400 block font-medium">
                      {item.count} {item.count === 1 ? 'venta realizada' : 'ventas realizadas'}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 bg-slate-50 px-3.5 py-2 rounded-xl">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-semibold">Total Cobrado</span>
                      <span className="font-extrabold text-emerald-700 text-sm">+ S/ {item.income.toFixed(2)}</span>
                    </div>
                    <div className="border-l border-slate-200 pl-3">
                      <span className="text-[10px] text-slate-400 block font-semibold">Ganancia Neta</span>
                      <span className="font-black text-teal-700 text-sm">
                        + S/ {item.profit.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
