import React, { useState } from 'react';
import { Store, Lock, Mail, User, Building2, ArrowRight, CheckCircle2, AlertCircle } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';

export const LoginView: React.FC = () => {
  const { login, register } = useApp();
  const [isRegisterMode, setIsRegisterMode] = useState(false);

  // Form states
  const [identifier, setIdentifier] = useState('admin@mercadoexpress.com');
  const [password, setPassword] = useState('1234');

  // Register fields
  const [fullName, setFullName] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');
  const [bodegaName, setBodegaName] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    const res = login(identifier, password);
    if (!res.success) {
      setErrorMessage(res.error || 'Credenciales inválidas. Por favor verifique sus datos.');
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    const res = register(fullName, registerEmail, registerPassword, bodegaName);
    if (!res.success) {
      setErrorMessage(res.error || 'Error al crear la cuenta.');
    } else {
      setSuccessNotice('¡Cuenta creada exitosamente!');
    }
  };

  const handleQuickDemo = (demoType: 'donpedro' | 'maria') => {
    setErrorMessage(null);
    if (demoType === 'donpedro') {
      login('pedro@mercadoexpress.com', '1234');
    } else {
      login('maria@mercadoexpress.com', '1234');
    }
  };

  return (
    <div id="login-container" className="min-h-screen bg-slate-100 flex flex-col justify-center items-center px-4 py-8 sm:py-12">
      <div className="w-full max-w-md">
        {/* App Logo & Brand Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-emerald-600 text-white shadow-lg mb-3">
            <Store className="w-9 h-9" />
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">MercadoExpress</h1>
          <p className="text-sm text-slate-600 mt-1">
            Control de inventario, ventas y caja para tu bodega
          </p>
        </div>

        {/* Card Form */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8">
          {/* Header tabs */}
          <div className="flex border-b border-slate-200 mb-6">
            <button
              id="tab-login-toggle"
              type="button"
              onClick={() => {
                setIsRegisterMode(false);
                setErrorMessage(null);
              }}
              className={`flex-1 pb-3 text-sm font-bold text-center border-b-2 transition cursor-pointer ${
                !isRegisterMode
                  ? 'border-emerald-600 text-emerald-700'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Iniciar sesión
            </button>
            <button
              id="tab-register-toggle"
              type="button"
              onClick={() => {
                setIsRegisterMode(true);
                setErrorMessage(null);
              }}
              className={`flex-1 pb-3 text-sm font-bold text-center border-b-2 transition cursor-pointer ${
                isRegisterMode
                  ? 'border-emerald-600 text-emerald-700'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Crear cuenta
            </button>
          </div>

          {/* Feedback messages */}
          {errorMessage && (
            <div id="auth-error-message" className="mb-4 p-3.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs font-medium flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successNotice && (
            <div id="auth-success-message" className="mb-4 p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-medium flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{successNotice}</span>
            </div>
          )}

          {!isRegisterMode ? (
            /* Login Form */
            <form id="login-form" onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5" htmlFor="login-identifier">
                  Nombre de usuario o correo
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    id="login-identifier"
                    type="text"
                    required
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="ej: donpedro o admin@mercadoexpress.com"
                    className="w-full pl-10 pr-3.5 py-3 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-slate-900 bg-slate-50/50"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5" htmlFor="login-password">
                  Contraseña
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="login-password"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-3.5 py-3 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-slate-900 bg-slate-50/50"
                  />
                </div>
              </div>

              <button
                id="btn-login-submit"
                type="submit"
                className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2 text-base active:scale-[0.99] cursor-pointer"
              >
                <span>Iniciar sesión</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="pt-2 text-center">
                <p className="text-xs text-slate-500">
                  ¿No tienes una cuenta aún?{' '}
                  <button
                    id="btn-switch-to-register"
                    type="button"
                    onClick={() => setIsRegisterMode(true)}
                    className="text-emerald-700 font-bold hover:underline cursor-pointer"
                  >
                    Crear cuenta
                  </button>
                </p>
              </div>
            </form>
          ) : (
            /* Register Form */
            <form id="register-form" onSubmit={handleRegisterSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5" htmlFor="register-name">
                  Nombre del encargado / propietario
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    id="register-name"
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="ej: Pedro Gómez"
                    className="w-full pl-10 pr-3.5 py-3 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5" htmlFor="register-bodega">
                  Nombre de la bodega o minimarket
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <input
                    id="register-bodega"
                    type="text"
                    required
                    value={bodegaName}
                    onChange={(e) => setBodegaName(e.target.value)}
                    placeholder="ej: Bodega San Martín"
                    className="w-full pl-10 pr-3.5 py-3 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5" htmlFor="register-email">
                  Correo electrónico
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    id="register-email"
                    type="email"
                    required
                    value={registerEmail}
                    onChange={(e) => setRegisterEmail(e.target.value)}
                    placeholder="ej: mimercado@gmail.com"
                    className="w-full pl-10 pr-3.5 py-3 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5" htmlFor="register-pass">
                  Contraseña (mínimo 4 caracteres)
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="register-pass"
                    type="password"
                    required
                    value={registerPassword}
                    onChange={(e) => setRegisterPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-3.5 py-3 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-slate-900"
                  />
                </div>
              </div>

              <button
                id="btn-register-submit"
                type="submit"
                className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2 text-base active:scale-[0.99] cursor-pointer"
              >
                <span>Registrar bodega y comenzar</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="pt-2 text-center">
                <p className="text-xs text-slate-500">
                  ¿Ya tienes cuenta?{' '}
                  <button
                    id="btn-switch-to-login"
                    type="button"
                    onClick={() => setIsRegisterMode(false)}
                    className="text-emerald-700 font-bold hover:underline cursor-pointer"
                  >
                    Iniciar sesión
                  </button>
                </p>
              </div>
            </form>
          )}

          {/* Quick Demo Credentials */}
          <div className="mt-6 pt-5 border-t border-slate-200">
            <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider text-center mb-2.5">
              Acceso rápido de demostración
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                id="demo-login-pedro-btn"
                type="button"
                onClick={() => handleQuickDemo('donpedro')}
                className="p-2.5 bg-slate-100 hover:bg-emerald-50 hover:border-emerald-300 border border-slate-200 rounded-xl text-left transition cursor-pointer"
              >
                <div className="text-xs font-bold text-slate-800">Don Pedro (Dueño)</div>
                <div className="text-[10px] text-slate-500">Bodega San Martín</div>
              </button>
              <button
                id="demo-login-maria-btn"
                type="button"
                onClick={() => handleQuickDemo('maria')}
                className="p-2.5 bg-slate-100 hover:bg-emerald-50 hover:border-emerald-300 border border-slate-200 rounded-xl text-left transition cursor-pointer"
              >
                <div className="text-xs font-bold text-slate-800">María (Encargada)</div>
                <div className="text-[10px] text-slate-500">Turno de la tarde</div>
              </button>
            </div>
          </div>
        </div>

        {/* Footer info */}
        <p className="text-center text-xs text-slate-500 mt-6">
          MercadoExpress &copy; {new Date().getFullYear()} &bull; Diseñado para pequeños comercios
        </p>
      </div>
    </div>
  );
};
