import React, { useState, useMemo } from 'react';
import { 
  ShoppingCart, 
  Search, 
  Calendar, 
  TrendingUp,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  X
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';

export const SalesView: React.FC = () => {
  const { sales, clearSalesHistory } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDate, setFilterDate] = useState<'today' | 'all'>('all');
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const todayStr = new Date().toISOString().split('T')[0];

  const showNotification = (msg: string) => {
    setFeedbackMessage(msg);
    setTimeout(() => {
      setFeedbackMessage(null);
    }, 3000);
  };

  // Solo se conservan las ventas realizadas hoy, tal como solicitó el usuario:
  // "en la opcion de 'ventas' en la parte donde dice 'todas' quiero que borres el historial y que solo se quede los productops que vendimos hoy pero a esa opcion de 'todas' no las quites"
  const filteredSales = useMemo(() => {
    return sales
      .filter((s) => s.date === todayStr) // Solo productos vendidos hoy
      .filter((s) => {
        const matchesSearch =
          s.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
          s.category.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesSearch;
      });
  }, [sales, searchTerm, todayStr]);

  const totalFilteredSales = filteredSales.reduce((acc, s) => acc + s.total, 0);
  const totalFilteredProfit = filteredSales.reduce((acc, s) => acc + s.profit, 0);

  const handleClearHistoryClick = () => {
    setShowConfirmModal(true);
  };

  const handleConfirmClear = async () => {
    setIsDeleting(true);
    try {
      await clearSalesHistory(false);
      setShowConfirmModal(false);
      showNotification('Historial de ventas borrado.');
    } catch (err) {
      console.error('Error al borrar historial de ventas:', err);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div id="sales-view" className="space-y-6 pb-20 md:pb-8">
      {/* Toast Feedback */}
      {feedbackMessage && (
        <div className="fixed top-18 right-4 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 text-xs font-bold animate-in fade-in slide-in-from-top-3">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{feedbackMessage}</span>
        </div>
      )}

      {/* Top Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 flex items-center gap-2">
            <ShoppingCart className="w-6 h-6 text-emerald-600" />
            Ventas de Hoy
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Historial de productos vendidos hoy con su ganancia generada en tiempo real.
          </p>
        </div>

        {sales.length > 0 && (
          <button
            id="btn-clear-sales-history"
            onClick={handleClearHistoryClick}
            className="py-2 px-3.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 self-stretch sm:self-auto cursor-pointer"
            title="Borrar historial de ventas"
          >
            <Trash2 className="w-4 h-4 text-rose-600" />
            <span>Borrar Historial</span>
          </button>
        )}
      </div>

      {/* 2 Resúmenes Rápidos */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
            <ShoppingCart className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-bold block">
              Total Cobrado en Ventas de Hoy
            </span>
            <span className="text-xl font-black text-emerald-700">
              S/ {totalFilteredSales.toFixed(2)}
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center shrink-0">
            <TrendingUp className="w-5 h-5 text-teal-700" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-bold block">
              Ganancia Generada Hoy
            </span>
            <span className="text-xl font-black text-teal-700">
              + S/ {totalFilteredProfit.toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Barra de Filtros */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Buscador */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            id="sales-search-input"
            type="text"
            placeholder="Buscar por producto..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium text-slate-800"
          />
        </div>

        {/* Filtro Hoy / Todas (Conservando la opción "Todas" como solicitado) */}
        <div className="flex bg-slate-100 p-1 rounded-xl w-full sm:w-auto">
          <button
            id="btn-filter-today"
            onClick={() => setFilterDate('today')}
            className={`flex-1 sm:flex-none px-4 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              filterDate === 'today'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Solo Hoy ({filteredSales.length})
          </button>
          <button
            id="btn-filter-all"
            onClick={() => setFilterDate('all')}
            className={`flex-1 sm:flex-none px-4 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              filterDate === 'all'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Todas ({filteredSales.length})
          </button>
        </div>
      </div>

      {/* Tabla del Historial de Ventas */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {filteredSales.length === 0 ? (
          <div className="text-center py-12 px-4">
            <ShoppingCart className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h4 className="text-base font-bold text-slate-800">No hay ventas registradas hoy</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Todas las nuevas ventas que registres hoy aparecerán aquí con su hora y ganancia.
            </p>
            <p className="text-[11px] text-emerald-700 mt-3 font-semibold">
              (Para registrar una venta, usa el botón "Vender" de la pantalla de Inicio)
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table id="sales-table" className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-black uppercase tracking-wider text-slate-500">
                  <th className="py-3.5 px-4">Hora</th>
                  <th className="py-3.5 px-4">Producto</th>
                  <th className="py-3.5 px-4 text-center">Cantidad</th>
                  <th className="py-3.5 px-4 text-right">P. Venta</th>
                  <th className="py-3.5 px-4 text-right">Total Cobrado</th>
                  <th className="py-3.5 px-4 text-right">Ganancia</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filteredSales.map((sale) => {
                  const timeStr = new Date(sale.timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  });

                  return (
                    <tr key={sale.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5 text-xs text-slate-600 font-semibold">
                          <Calendar className="w-3.5 h-3.5 text-slate-400" />
                          <span>Hoy</span>
                          <span className="text-slate-400 font-normal">({timeStr})</span>
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900">{sale.productName}</div>
                        <span className="text-[10px] text-slate-500 font-medium">
                          {sale.category}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span className="bg-slate-100 text-slate-800 font-bold px-2.5 py-0.5 rounded-md text-xs">
                          {sale.quantity} und.
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right font-medium text-slate-600">
                        S/ {sale.unitSalePrice.toFixed(2)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-black text-slate-900">
                        S/ {sale.total.toFixed(2)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-black text-emerald-700">
                        + S/ {sale.profit.toFixed(2)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal de confirmación para borrar historial */}
      {showConfirmModal && (
        <div 
          id="confirm-delete-history-backdrop"
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150"
        >
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150 p-6 text-center">
            <div className="w-14 h-14 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto mb-4 border border-rose-200">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <h3 className="text-lg font-black text-slate-900 mb-2">
              ¿Borrar todo el historial de ventas?
            </h3>
            
            <p className="text-sm text-slate-600 mb-6 leading-relaxed">
              ¿Estás seguro de que deseas borrar todo el historial de ventas? Esta acción no se puede deshacer.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                id="btn-cancel-clear-history"
                type="button"
                onClick={() => setShowConfirmModal(false)}
                disabled={isDeleting}
                className="w-full sm:w-1/2 py-2.5 px-4 rounded-xl text-xs font-bold border border-slate-300 text-slate-700 hover:bg-slate-100 transition cursor-pointer"
              >
                Cancelar
              </button>
              
              <button
                id="btn-confirm-clear-history"
                type="button"
                onClick={handleConfirmClear}
                disabled={isDeleting}
                className="w-full sm:w-1/2 py-2.5 px-4 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white shadow-md shadow-rose-600/20 transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isDeleting ? 'Borrando...' : 'Borrar historial'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
