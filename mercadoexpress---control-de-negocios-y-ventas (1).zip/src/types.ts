export type ProductCategory =
  | 'Abarrotes'
  | 'Bebidas y Licores'
  | 'Lácteos y Huevos'
  | 'Limpieza y Aseo'
  | 'Snacks y Golosinas'
  | 'Frutas y Verduras'
  | 'Panadería y Embutidos'
  | 'Cuidado Personal'
  | 'Otros';

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  stock: number;
  purchasePrice: number; // Precio de compra
  salePrice: number;     // Precio de venta
  minStock: number;      // Alerta cuando stock <= minStock
  updatedAt: string;
}

export interface Sale {
  id: string;
  productId: string;
  productName: string;
  category: ProductCategory;
  quantity: number;
  unitPurchasePrice: number; // Costo (lo que te dan)
  unitSalePrice: number;     // Venta (al público)
  total: number;             // Total cobrado
  profit: number;            // Ganancia neta
  amountPaid?: number;       // Dinero recibido
  change?: number;           // Vuelto
  date: string;              // YYYY-MM-DD
  timestamp: string;         // Fecha y hora ISO
}

export interface UserSession {
  id: string;
  name: string;
  email: string;
  bodegaName: string;
}

export type ActiveTab = 'dashboard' | 'sales' | 'products' | 'cashflow';
